import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table definition - stores user account information
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  avatar: text("avatar"),
  bio: text("bio"),
  countriesVisited: integer("countries_visited").default(0),
});

// Schema for validating user data on insert
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
  avatar: true,
  bio: true,
  countriesVisited: true,
});

// Trip table - stores travel itinerary information
export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  destination: text("destination").notNull(),
  coverImage: text("cover_image"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status").notNull().default("draft"), // Status can be: draft, in-progress, completed
  itinerary: jsonb("itinerary"), // Stores day-by-day trip details
});

// Schema for validating trip data on insert
export const insertTripSchema = createInsertSchema(trips).pick({
  userId: true,
  title: true,
  destination: true,
  coverImage: true,
  startDate: true,
  endDate: true,
  status: true,
  itinerary: true,
});

// Story table - stores travel stories/posts
export const stories = pgTable("stories", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  tripId: integer("trip_id"), // Optional link to a specific trip
  title: text("title").notNull(),
  location: text("location").notNull(),
  coverImage: text("cover_image").notNull(),
  content: text("content").notNull(),
  photos: jsonb("photos"), // Array of photo URLs
  createdAt: timestamp("created_at").notNull().defaultNow(),
  likes: integer("likes").default(0),
  comments: integer("comments").default(0),
});

// Schema for validating story data on insert
export const insertStorySchema = createInsertSchema(stories).pick({
  userId: true,
  tripId: true,
  title: true,
  location: true,
  coverImage: true,
  content: true,
  photos: true,
});

// Activity table - stores individual activities within a trip
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  tripId: integer("trip_id").notNull(),
  day: integer("day").notNull(),
  type: text("type").notNull(), // Type can be: flight, hotel, restaurant, attraction
  title: text("title").notNull(),
  time: text("time"),
  location: text("location"),
  notes: text("notes"),
});

// Schema for validating activity data on insert
export const insertActivitySchema = createInsertSchema(activities).pick({
  tripId: true,
  day: true,
  type: true,
  title: true,
  time: true,
  location: true,
  notes: true,
});

// Place table - stores saved locations/points of interest
export const places = pgTable("places", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  tripId: integer("trip_id"),
  name: text("name").notNull(),
  category: text("category").notNull(), // Category can be: food, attraction, hotel
  address: text("address"),
  lat: text("lat"),
  lng: text("lng"),
  rating: text("rating"),
  photo: text("photo"),
});

// Schema for validating place data on insert
export const insertPlaceSchema = createInsertSchema(places).pick({
  userId: true,
  tripId: true,
  name: true,
  category: true,
  address: true,
  lat: true,
  lng: true,
  rating: true,
  photo: true,
});

// Collection table - groups places, trips, or stories
export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  coverImage: text("cover_image"),
  items: jsonb("items"), // Array of item IDs
  itemType: text("item_type").notNull(), // Type can be: place, trip, or story
});

// Schema for validating collection data on insert
export const insertCollectionSchema = createInsertSchema(collections).pick({
  userId: true,
  title: true,
  coverImage: true,
  items: true,
  itemType: true,
});

// Export TypeScript types for use in the application
export type User = typeof users.$inferSelect;
export type Trip = typeof trips.$inferSelect;
export type Story = typeof stories.$inferSelect;
export type Activity = typeof activities.$inferSelect;
export type Place = typeof places.$inferSelect;
export type Collection = typeof collections.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertTrip = z.infer<typeof insertTripSchema>;
export type InsertStory = z.infer<typeof insertStorySchema>;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type InsertPlace = z.infer<typeof insertPlaceSchema>;
export type InsertCollection = z.infer<typeof insertCollectionSchema>;