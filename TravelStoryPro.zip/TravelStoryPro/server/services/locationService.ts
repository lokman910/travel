import { 
  Client, 
  PlaceInputType, 
  Language, 
  AddressType, 
  GeocodingAddressComponentType 
} from '@googlemaps/google-maps-services-js';
import { Place } from '@shared/schema';

const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;

if (!GOOGLE_MAPS_API_KEY) {
  console.error('Missing GOOGLE_MAPS_API_KEY environment variable');
}

const googleMapsClient = new Client({});

interface LocationCoordinates {
  lat: number;
  lng: number;
}

interface NearbyAttraction {
  id: string;
  name: string;
  placeId: string;
  location: LocationCoordinates;
  address: string;
  types: string[];
  rating: number;
  photoUrl?: string;
  distance?: string;
  openNow?: boolean;
}

interface CityInfo {
  name: string;
  country: string;
  coordinates: LocationCoordinates;
  description: string;
  photoUrl?: string;
}

export async function geocodeLocation(address: string): Promise<LocationCoordinates | null> {
  try {
    const response = await googleMapsClient.geocode({
      params: {
        address,
        key: GOOGLE_MAPS_API_KEY!,
      },
    });

    if (response.data.results && response.data.results.length > 0) {
      const location = response.data.results[0].geometry.location;
      return {
        lat: location.lat,
        lng: location.lng,
      };
    }

    return null;
  } catch (error) {
    console.error('Error geocoding address:', error);
    return null;
  }
}

export async function reverseGeocode(coordinates: LocationCoordinates): Promise<string | null> {
  try {
    const response = await googleMapsClient.reverseGeocode({
      params: {
        latlng: coordinates,
        // Use string array without type constraints since the API accepts more types than the TS definitions
        result_type: ['locality', 'political'] as any,
        key: GOOGLE_MAPS_API_KEY!,
      },
    });

    if (response.data.results && response.data.results.length > 0) {
      return response.data.results[0].formatted_address;
    }

    return null;
  } catch (error) {
    console.error('Error reverse geocoding:', error);
    return null;
  }
}

export async function getCurrentCity(coordinates: LocationCoordinates): Promise<CityInfo | null> {
  try {
    console.log('SERVER - Getting current city for coordinates:', coordinates);
    console.log('SERVER - GOOGLE_MAPS_API_KEY exists:', !!GOOGLE_MAPS_API_KEY);
    
    if (!GOOGLE_MAPS_API_KEY) {
      console.error('SERVER - Missing Google Maps API key!');
      // Return fallback data for testing if API key is missing
      const fallbackData = {
        name: "Current Location",
        country: "Local Area",
        coordinates,
        description: "Your current location. API key missing, please configure Google Maps API key."
      };
      console.log('SERVER - Using fallback data:', fallbackData);
      return fallbackData;
    }
    
    console.log('SERVER - Making reverse geocode request to Google Maps API...');
    
    const response = await googleMapsClient.reverseGeocode({
      params: {
        latlng: coordinates,
        // Use string array without type constraints since the API accepts more types than the TS definitions
        result_type: ['locality', 'political'] as any,
        key: GOOGLE_MAPS_API_KEY!,
      },
    });

    console.log('SERVER - Google API response status:', response.status);
    console.log('SERVER - Google API response has results:', !!response.data.results?.length);
    
    if (response.data.results && response.data.results.length > 0) {
      console.log('SERVER - Found location results:', response.data.results.length);
      const result = response.data.results[0];
      let city = '';
      let country = '';

      // Extract city and country from address components
      for (const component of result.address_components) {
        console.log('SERVER - Address component:', component.types, component.long_name);
        if (component.types.includes('locality' as any)) {
          city = component.long_name;
        } else if (component.types.includes('country' as any)) {
          country = component.long_name;
        }
      }

      console.log('SERVER - Extracted city and country:', city, country);

      if (city && country) {
        const cityInfo = {
          name: city,
          country,
          coordinates,
          description: `${city} is a beautiful city in ${country}.`,
          // We'll add photo in a separate call or use a default
        };
        console.log('SERVER - Returning city info:', cityInfo);
        return cityInfo;
      }
    } else {
      console.log('SERVER - No results found in Google API response');
    }

    return null;
  } catch (error) {
    console.error('SERVER - Error getting current city:', error);
    return null;
  }
}

export async function getNearbyAttractions(
  coordinates: LocationCoordinates,
  radius: number = 5000,
  type: string = 'tourist_attraction'
): Promise<NearbyAttraction[]> {
  try {
    const response = await googleMapsClient.placesNearby({
      params: {
        location: coordinates,
        radius,
        type: type as PlaceInputType,
        key: GOOGLE_MAPS_API_KEY!,
        language: 'en' as Language,
      },
    });

    if (response.data.results) {
      return response.data.results.map((place) => {
        // Handle potential undefined values safely
        if (!place.geometry || !place.geometry.location) {
          console.warn('Found place without geometry:', place.name);
          return null;
        }
        
        // Calculate a simplified distance (in km)
        const distance = calculateDistance(
          coordinates.lat,
          coordinates.lng,
          place.geometry.location.lat,
          place.geometry.location.lng
        );

        return {
          id: place.place_id || `place-${Date.now()}-${Math.random()}`,
          name: place.name || 'Unnamed Location',
          placeId: place.place_id || `place-${Date.now()}-${Math.random()}`,
          location: {
            lat: place.geometry.location.lat,
            lng: place.geometry.location.lng,
          },
          address: place.vicinity || 'Address not available',
          types: place.types || ['attraction'],
          rating: place.rating || 0,
          photoUrl: place.photos && place.photos.length > 0
            ? `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${place.photos[0].photo_reference}&key=${GOOGLE_MAPS_API_KEY}`
            : undefined,
          distance: `${distance.toFixed(1)} km`,
          openNow: place.opening_hours?.open_now,
        };
      }).filter(Boolean) as NearbyAttraction[]; // Filter out null values
    }

    return [];
  } catch (error) {
    console.error('Error getting nearby attractions:', error);
    return [];
  }
}

export async function getPopularDestinations(
  baseCoordinates: LocationCoordinates,
  radius: number = 200000 // 200km to find broader destinations
): Promise<CityInfo[]> {
  try {
    // Find cities near the user's location
    const response = await googleMapsClient.placesNearby({
      params: {
        location: baseCoordinates,
        radius,
        type: 'locality' as PlaceInputType,
        key: GOOGLE_MAPS_API_KEY!,
      },
    });

    if (response.data.results) {
      const destinations: CityInfo[] = [];
      
      for (const place of response.data.results.slice(0, 5)) { // Limit to 5 destinations
        // Skip places without geometry
        if (!place.geometry || !place.geometry.location) {
          console.warn('Found place without geometry:', place.name);
          continue;
        }
        
        try {
          const detailsResponse = await googleMapsClient.placeDetails({
            params: {
              place_id: place.place_id || '',
              fields: ['name', 'formatted_address', 'geometry', 'photo'],
              key: GOOGLE_MAPS_API_KEY!,
            },
          });
          
          const details = detailsResponse.data.result;
          if (details) {
            let country = 'Unknown Country';
            const addressParts = details.formatted_address?.split(',') || [];
            if (addressParts.length > 0) {
              country = addressParts[addressParts.length - 1].trim() || 'Unknown Country';
            }
            
            const lat = details.geometry?.location.lat || place.geometry.location.lat;
            const lng = details.geometry?.location.lng || place.geometry.location.lng;
            
            destinations.push({
              name: details.name || place.name || 'Unnamed Location',
              country: country,
              coordinates: { lat, lng },
              description: `A popular destination near you.`,
              photoUrl: details.photos && details.photos.length > 0
                ? `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${details.photos[0].photo_reference}&key=${GOOGLE_MAPS_API_KEY}`
                : undefined,
            });
          }
        } catch (detailsError) {
          console.error('Error fetching place details:', detailsError);
          // Skip this place but continue with others
          continue;
        }
      }
      
      return destinations;
    }

    return [];
  } catch (error) {
    console.error('Error getting popular destinations:', error);
    return [];
  }
}

// Helper function to calculate distance between two points using Haversine formula
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in km
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

// Convert Google Places result to our app's Place schema
export function convertToAppPlace(attraction: NearbyAttraction): Place {
  // Generate a stable numeric ID - we convert the place ID string into a number
  let numericId: number;
  try {
    // Extract 8 characters max to avoid overflow and parse as hex
    numericId = parseInt(attraction.id.substring(0, 8), 16);
    // If the parsed value is NaN, create a random ID
    if (isNaN(numericId)) {
      numericId = Math.floor(Math.random() * 100000);
    }
  } catch (e) {
    // Fallback to random ID if parsing fails
    numericId = Math.floor(Math.random() * 100000);
  }
  
  // Format the rating as a string
  const ratingStr = attraction.rating.toString();
  
  // Create a proper Place object that matches our schema
  return {
    id: numericId,
    userId: 1, // Default user ID
    tripId: null, // Not associated with a trip initially
    name: attraction.name,
    category: attraction.types[0] || 'attraction',
    address: attraction.address,
    lat: attraction.location.lat.toString(),
    lng: attraction.location.lng.toString(),
    rating: ratingStr,
    photo: attraction.photoUrl || '',
  };
}