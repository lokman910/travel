
// Using in-memory cache instead of Redis due to connection issues
interface CacheItem {
  value: any;
  expiry: number;
}

const inMemoryCache: Map<string, CacheItem> = new Map();

const DEFAULT_CACHE_TTL = 3600; // 1 hour in seconds

// Clean up expired cache items every minute
setInterval(() => {
  const now = Date.now();
  // Use Array.from to avoid TypeScript iteration issues
  Array.from(inMemoryCache.entries()).forEach(([key, item]) => {
    if (item.expiry < now) {
      inMemoryCache.delete(key);
    }
  });
}, 60000);

export const cacheService = {
  async get(key: string) {
    try {
      const item = inMemoryCache.get(key);
      
      // Return null if item doesn't exist or has expired
      if (!item || item.expiry < Date.now()) {
        if (item) {
          // Clean up expired item
          inMemoryCache.delete(key);
        }
        return null;
      }
      
      console.log(`Cache hit for: ${key}`);
      return item.value;
    } catch (error) {
      console.error('Cache get error:', error);
      return null;
    }
  },

  async set(key: string, value: any, ttl = DEFAULT_CACHE_TTL) {
    try {
      // Calculate expiry time in milliseconds
      const expiry = Date.now() + (ttl * 1000);
      
      inMemoryCache.set(key, { 
        value, 
        expiry 
      });
      
      console.log(`Cached: ${key} (expires in ${ttl} seconds)`);
    } catch (error) {
      console.error('Cache set error:', error);
    }
  }
};
