import { GoogleGenerativeAI, GenerativeModel, HarmCategory, HarmBlockThreshold } from '@google/generative-ai';
import { Place } from '@shared/schema';

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

if (!GEMINI_API_KEY) {
  console.error('Missing GEMINI_API_KEY environment variable');
}

// Initialize the Google Generative AI SDK
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY || '');

// Use the correct model version with proper safety settings
const generationConfig = {
  temperature: 0.7,
  topP: 0.8,
  topK: 40,
};

const safetySettings = [
  {
    category: HarmCategory.HARM_CATEGORY_HARASSMENT,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
  {
    category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
  {
    category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
  {
    category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
];

const model = genAI.getGenerativeModel({ 
  model: 'gemini-1.5-pro',
  generationConfig,
  safetySettings,
});

/**
 * Advanced contextual recommendation engine based on multiple user and environment factors
 */

// User Context related interfaces
interface UserContext {
  currentLocation: LocationInfo;
  homeLocation?: LocationInfo;
  currentTime: Date;
  weather?: WeatherInfo;
  isLocal: boolean;
}

interface WeatherInfo {
  condition: string; // sunny, rainy, cloudy, etc.
  temperature: number;
  feelsLike: number;
  precipitation: number;
  humidity: number;
  windSpeed: number;
}

// User Preference related interfaces
interface UserPreferences {
  interestCategories: string[];
  budgetPreference?: 'free' | 'moderate' | 'premium';
  categoryEngagement?: Record<string, number>; // category -> engagement rate
  activityHistory?: string[];
  durationPreference?: number; // in minutes
  accessibilityRequirements?: string[];
  filters?: Record<string, any>;
  favorites?: string[];
}

// Behavioral data related interfaces
interface UserBehavioralData {
  viewedLocations?: string[];
  savedLocations?: string[];
  visitedLocations?: string[];
  dismissedRecommendations?: string[];
  viewDurations?: Record<string, number>;
  clickPatterns?: Record<string, number>;
  completedActivities?: string[];
  abandonedActivities?: string[];
  searchHistory?: string[];
  featureUsage?: {
    mapPreference: boolean;
    listPreference: boolean;
  };
}

// Social and community data
interface SocialData {
  friendActivities?: string[];
  similarUserChoices?: string[];
  localPopularity?: number;
  touristPopularity?: number;
  trending?: boolean;
  seasonalRelevance?: number; // 0-1 scale
  specialEvent?: boolean;
  expertValidated?: boolean;
  frequentPairs?: string[];
}

// Location specific data
interface EnhancedLocationData {
  operatingHours?: {
    open: string;
    close: string;
    isOpen: boolean;
  };
  typicalDuration?: number; // in minutes
  busyness?: number; // 0-1 scale
  crowdPatterns?: Record<string, number>;
  distanceFromUser?: number; // in km
  travelTime?: number; // in minutes
  weatherDependency?: number; // 0-1 scale
  userReports?: string[];
  accessibilityFeatures?: string[];
  cost?: number;
  valueRating?: number;
  categories?: string[];
  subcategories?: string[];
  peakTimes?: string[];
  seasonalFactors?: string[];
}

interface LocationInfo {
  city: string;
  country: string;
  lat: number;
  lng: number;
}

export interface PerfectRecommendation {
  name: string;
  description: string;
  category: string;
  whyPerfect: string;
  bestTimeToVisit?: string;
  estimatedTimeNeeded?: string;
  placeId?: string;
  photoReference?: string;
  rating?: number;
  totalRatings?: number;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

import { Client, FindPlaceFromTextResponseData, PlaceInputType } from '@googlemaps/google-maps-services-js';

const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;
const googleMapsClient = new Client({});

/**
 * Contextual relevance scoring for recommendations
 * Calculates a score based on multiple factors to rank recommendations
 */
interface RecommendationScore {
  immediateRelevanceScore: number;  // Time-sensitive opportunities
  proximityScore: number;           // Distance and accessibility
  weatherAppropriateScore: number;  // Weather match
  timeOfDayScore: number;           // Time of day suitability
  userPreferenceScore: number;      // Match with user preferences
  discoveryPotentialScore: number;  // New experiences aligned with tastes
  socialValidationScore: number;    // Social validation factors
  intentMatchScore: number;         // Match with user intent
  totalScore: number;               // Composite score
}

/**
 * Calculate contextual relevance score for a recommendation based on multiple factors
 * This implementation uses a more sophisticated scoring algorithm that considers
 * user context, preferences, and activity characteristics
 */
function calculateRelevanceScore(
  recommendation: PerfectRecommendation,
  userContext: Partial<UserContext> = {},
  userPreferences: Partial<UserPreferences> = {},
  socialData: Partial<SocialData> = {},
  locationData: Partial<EnhancedLocationData> = {}
): RecommendationScore {
  // Initialize scores with base values
  const scores: RecommendationScore = {
    immediateRelevanceScore: 0.5,  // Time-sensitive opportunities
    proximityScore: 0.5,           // Distance and accessibility
    weatherAppropriateScore: 0.5,  // Weather appropriateness
    timeOfDayScore: 0.5,           // Time of day suitability
    userPreferenceScore: 0.5,      // Match with user preferences
    discoveryPotentialScore: 0.5,  // New experiences aligned with tastes
    socialValidationScore: 0.5,    // Social validation factors
    intentMatchScore: 0,           // Match with explicit user intent
    totalScore: 0                  // Composite score
  };

  // Time of day scoring - highest priority factor
  if (userContext.currentTime) {
    const hour = userContext.currentTime.getHours();
    
    // Apply the same timezone adjustment as used in getPerfectRecommendations
    const pacificTimeOffset = -7; // UTC-7 for Pacific Daylight Time
    const clientHour = (hour + pacificTimeOffset + 24) % 24; // Ensure positive hour
    
    const recommendedTimeRange = recommendation.bestTimeToVisit || "";
    const category = recommendation.category.toLowerCase();

    // Check for completely inappropriate activities for time of day
    const outdoorActivities = ['hiking', 'park', 'trail', 'garden', 'overlook', 'viewpoint', 'outdoor'];
    const isOutdoorActivity = outdoorActivities.some(term => category.includes(term));

    // Night time (after 8pm or before 6am)
    if (clientHour >= 20 || clientHour < 6) {
      if (isOutdoorActivity) {
        // Completely eliminate outdoor activities at night unless they're explicitly for night viewing
        scores.timeOfDayScore = recommendedTimeRange.toLowerCase().includes('night') ? 0.3 : 0.01;
      } else if (category.includes('nightlife') || category.includes('bar') || 
                category.includes('club') || category.includes('entertainment') || 
                category.includes('dining') || category.includes('restaurant')) {
        // Strongly favor appropriate nighttime venues
        scores.timeOfDayScore = 1.0;
      } else if (category.includes('museum') || category.includes('gallery') || 
                category.includes('shopping')) {
        // Severely penalize daytime-focused activities
        scores.timeOfDayScore = 0.05;
      } else {
        scores.timeOfDayScore = 0.4;
      }
    }
    // Early morning (6-9am)
    else if (clientHour >= 6 && clientHour < 9) {
      if (recommendedTimeRange.toLowerCase().includes('morning') || 
          recommendedTimeRange.toLowerCase().includes('sunrise') ||
          recommendedTimeRange.toLowerCase().includes('early')) {
        scores.timeOfDayScore = 1.0;
      } else if (category.includes('breakfast') || category.includes('coffee')) {
        scores.timeOfDayScore = 0.9;
      } else if (category.includes('nightlife') || category.includes('bar') || category.includes('club')) {
        scores.timeOfDayScore = 0.01; // Severely penalize nightlife in morning
      } else {
        scores.timeOfDayScore = 0.5;
      }
    }
    // Late morning (9-12)
    else if (clientHour >= 9 && clientHour < 12) {
      if (recommendedTimeRange.toLowerCase().includes('morning')) {
        scores.timeOfDayScore = 0.9;
      } else if (category.includes('brunch') || category.includes('cafe')) {
        scores.timeOfDayScore = 0.8;
      } else if (category.includes('nightlife')) {
        scores.timeOfDayScore = 0.1;
      } else {
        scores.timeOfDayScore = 0.5;
      }
    }
    // Afternoon (12-17)
    else if (clientHour >= 12 && clientHour < 17) {
      if (recommendedTimeRange.toLowerCase().includes('afternoon')) {
        scores.timeOfDayScore = 0.9;
      } else if (category.includes('lunch') || isOutdoorActivity) {
        scores.timeOfDayScore = 0.8;
      } else if (category.includes('nightlife')) {
        scores.timeOfDayScore = 0.1;
      } else {
        scores.timeOfDayScore = 0.6;
      }
    }
    // Evening (17-20)
    else if (clientHour >= 17 && clientHour < 20) {
      if (recommendedTimeRange.toLowerCase().includes('evening') || 
          recommendedTimeRange.toLowerCase().includes('sunset')) {
        scores.timeOfDayScore = 0.9;
      } else if (category.includes('dinner') || category.includes('restaurant')) {
        scores.timeOfDayScore = 0.8;
      } else if (isOutdoorActivity && !recommendedTimeRange.toLowerCase().includes('sunset')) {
        scores.timeOfDayScore = 0.4; // Lower score for outdoor activities in evening unless sunset viewing
      } else {
        scores.timeOfDayScore = 0.5;
      }
    }
    // Evening & Night (20-23)
    else if (clientHour >= 20 && clientHour < 23) {
      if (recommendedTimeRange.toLowerCase().includes('night')) {
        scores.timeOfDayScore = 1.0;
      } else if (category.includes('bar') || category.includes('club') || category.includes('nightlife') ||
                category.includes('entertainment') || category.includes('dining') || category.includes('restaurant')) {
        scores.timeOfDayScore = 1.0; // Maximum score for nightlife venues at night
      } else if (category.includes('cinema') || category.includes('theater') || category.includes('comedy')) {
        scores.timeOfDayScore = 0.95; // Very high score for evening entertainment
      } else if (isOutdoorActivity) {
        scores.timeOfDayScore = 0.05; // Severely penalize outdoor activities at night
      } else if (category.includes('museum') || category.includes('gallery') || category.includes('shopping')) {
        scores.timeOfDayScore = 0.05; // Severely penalize daytime activities
      } else {
        scores.timeOfDayScore = 0.3;
      }
    }
    // Late night (23-6)
    else {
      if (recommendedTimeRange.toLowerCase().includes('night') || category.includes('nightlife')) {
        scores.timeOfDayScore = 0.9;
      } else if (category.includes('bar') || category.includes('club') || category.includes('lounge')) {
        scores.timeOfDayScore = 0.9;
      } else if (category.includes('restaurant') && recommendedTimeRange.toLowerCase().includes('late')) {
        scores.timeOfDayScore = 0.8; // Good score for late-night restaurants
      } else if (isOutdoorActivity) {
        scores.timeOfDayScore = 0.01; // Almost completely eliminate outdoor activities after midnight
      } else if (category.includes('museum') || category.includes('gallery') || category.includes('shopping')) {
        scores.timeOfDayScore = 0.01; // Almost completely eliminate daytime venues
      } else {
        scores.timeOfDayScore = 0.2;
      }
    }
  }

  // Weather appropriateness scoring
  if (userContext.weather) {
    const isOutdoor = ['park', 'garden', 'hiking', 'beach', 'viewpoint', 'outdoor'].some(
      term => recommendation.category.toLowerCase().includes(term)
    );

    const goodWeather = ['sunny', 'clear', 'partly cloudy'].includes(userContext.weather.condition.toLowerCase());

    if (isOutdoor && goodWeather) {
      scores.weatherAppropriateScore = 0.9;
    } else if (isOutdoor && !goodWeather) {
      scores.weatherAppropriateScore = 0.1;
    } else if (!isOutdoor && !goodWeather) {
      scores.weatherAppropriateScore = 0.8;
    }
  }

  // Proximity scoring
  if (locationData.distanceFromUser !== undefined) {
    // Closer is better (inverse relationship)
    scores.proximityScore = Math.max(0, 1 - (locationData.distanceFromUser / 10)); // Normalized to 0-1 for distances 0-10km
  }

  // User preference scoring
  if (userPreferences.interestCategories && userPreferences.interestCategories.length > 0) {
    const matchingCategories = userPreferences.interestCategories.filter(
      category => recommendation.category.toLowerCase().includes(category.toLowerCase())
    );

    scores.userPreferenceScore = matchingCategories.length / userPreferences.interestCategories.length;
  }

  // Social validation scoring
  if (recommendation.rating !== undefined && recommendation.totalRatings !== undefined) {
    // Weighted combination of rating and number of ratings
    const normalizedRating = (recommendation.rating || 3) / 5;
    const normalizedTotalRatings = Math.min(recommendation.totalRatings || 0, 1000) / 1000;

    scores.socialValidationScore = (normalizedRating * 0.7) + (normalizedTotalRatings * 0.3);
  }

  // Intent Matching Score
  if (userPreferences.interestCategories?.length === 1) {
    const intent = userPreferences.interestCategories[0].toLowerCase();
    const category = recommendation.category.toLowerCase();
    const intentKeywords: Record<string, RegExp[]> = {
      food: [/restaurant|cafe|dining|food/i],
      relax: [/spa|park|lounge|garden/i],
      adventure: [/trail|sport|hike|adventure/i],
      culture: [/museum|gallery|historic|cultural/i],
      photo_spots: [/view|scenic|photogenic/i],
      hidden_gems: [/hidden|local|unique/i],
      sunset_spots: [/sunset|view|overlook/i],
      local_life: [/local|community|authentic/i]
    };

    if (intent in intentKeywords && intentKeywords[intent].some((regex: RegExp) => regex.test(category))) {
      scores.intentMatchScore = 0.5; // Add a significant bonus for intent match
    }
  }

  // Calculate total score with a strong focus on time relevance but with less proximity restriction
  // Time of day (35%) remains important but allows for more diversity
  // User preferences (20%) and discovery potential (15%) are weighted for personalization
  // Proximity is reduced to just 5% to allow excellent but farther places to show
  // Social validation (10%) helps surface popular places
  // The remaining factors create a well-balanced recommendation
  scores.totalScore = (
    (scores.immediateRelevanceScore * 0.10) +  // Time-sensitive opportunities
    (scores.proximityScore * 0.05) +           // Distance factor reduced to allow farther relevant places
    (scores.weatherAppropriateScore * 0.05) +  // Weather appropriateness
    (scores.timeOfDayScore * 0.35) +           // Time of day suitability (important but balanced)
    (scores.userPreferenceScore * 0.20) +      // Match with user preferences
    (scores.discoveryPotentialScore * 0.15) +  // Greater emphasis on discovery
    (scores.socialValidationScore * 0.10) +    // Social validation factors
    (scores.intentMatchScore * 0.10)           // Match with explicit user intent (increased)
  );

  return scores;
}

/**
 * Get perfect recommendations for today based on contextual factors
 */
export async function getPerfectRecommendations(
  location: LocationInfo,
  city?: string,
  country?: string,
  intent: string | null = null,
  date: Date = new Date()
): Promise<PerfectRecommendation[]> {
  try {
    // Create cache key based on location, date and intent
    const dateStr = date.toISOString().split('T')[0]; // Get just the date part
    const cacheKey = `recommendations:${location.lat},${location.lng}:${dateStr}:${intent || 'default'}`;
    
    // Check cache first
    const cachedRecommendations = await cacheService.get(cacheKey);
    if (cachedRecommendations) {
      console.log('Returning cached recommendations');
      return cachedRecommendations;
    }
    // Create basic user context
    const userContext: Partial<UserContext> = {
      currentLocation: location,
      currentTime: date,
      isLocal: false // Assume the user is not local by default
    };

    // Create basic user preferences
    const userPreferences: Partial<UserPreferences> = {
      interestCategories: intent ? [intent] : []
    };

    const dayOfWeek = new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(date);
    const month = new Intl.DateTimeFormat('en-US', { month: 'long' }).format(date);
    const hour = date.getHours();

    // Use the client's local time (from the request) rather than server time
    // The date object passed from the client has the correct timezone information

    // Adjust for Pacific Time (Los Angeles) for demonstration purposes
    // This simulates the location being in LA with appropriate time
    // In production, we'd use the user's actual location for timezone
    const pacificTimeOffset = -7; // UTC-7 for Pacific Daylight Time
    const clientHour = (hour + pacificTimeOffset + 24) % 24; // Ensure positive hour

    // Determine time of day for contextual prompt with precise time descriptions
    let timeOfDay = "day";
    if (clientHour >= 5 && clientHour < 8) {
      timeOfDay = "early morning";
    } else if (clientHour >= 8 && clientHour < 12) {
      timeOfDay = "morning";
    } else if (clientHour >= 12 && clientHour < 15) {
      timeOfDay = "midday/lunch";
    } else if (clientHour >= 15 && clientHour < 17) {
      timeOfDay = "afternoon";
    } else if (clientHour >= 17 && clientHour < 20) {
      timeOfDay = "evening";
    } else if (clientHour >= 20 && clientHour < 24) {
      timeOfDay = "night";
    } else {
      timeOfDay = "late night";
    }
    
    console.log(`Time detection: ${hour}:00 UTC is adjusted to ${clientHour}:00 local (${timeOfDay})`);  // Debug time detection

    const cityName = city || location.city;
    const countryName = country || location.country;

    // Advanced contextually-aware prompt with comprehensive relevance factors
    const prompt = `
      You are an AI-powered recommendation engine that delivers highly personalized, contextually relevant 
      activity suggestions based on a user's current context and preferences. As a local expert in ${cityName}, ${countryName},
      recommend exactly 4 perfect places to visit RIGHT NOW at ${clientHour}:00 (${timeOfDay}) on ${dayOfWeek} in ${month}.

      ${intent ? `The user's current interest is: ${intent}` : 'The user has not specified a particular interest.'}

      *** CRITICAL: VERIFY CURRENT TIME CONTEXT (${clientHour}:00) ***
      Your recommendations MUST be appropriate for the time of day and be places that would typically be open and 
      active at ${clientHour}:00 - this is your most important constraint.

      Time-appropriate recommendation guidelines:
      - LATE NIGHT (12am-5am): Only 24-hour diners, certain nightclubs, observation points, star-gazing spots
      - EARLY MORNING (5am-8am): Breakfast spots, coffee shops, bakeries, sunrise viewpoints, parks for early joggers
      - MORNING (8am-12pm): Cafes, museums just opening, parks, shopping, tourist attractions, morning markets
      - MIDDAY/LUNCH (12pm-3pm): Restaurants, food markets, museums, shops, outdoor activities
      - AFTERNOON (3pm-5pm): Museums, parks, shopping, cafes, tourist attractions, historical sites
      - EVENING (5pm-8pm): Dinner spots, sunset viewpoints, early entertainment venues, evening markets, evening tours
      - NIGHT (8pm-12am): Bars, clubs, night markets, entertainment venues, stargazing spots, illuminated monuments

      Current time: ${clientHour}:00 (${timeOfDay})
      
      *** VERIFY OPERATING HOURS: Only recommend places that would ACTUALLY be open at ${clientHour}:00 ***
      Consider typical business hours - for example:
      - Most museums close by 5-6pm
      - Many restaurants close between 2-5pm between lunch and dinner
      - Most nightlife venues don't open until 8-10pm
      - Parks may close after sunset or not be appropriate for visiting in darkness

      Consider these additional contextual factors:
      1. DIVERSITY: Include recommendations from at least 3 different categories (food, culture, outdoors, entertainment)
      2. RELEVANCE: Focus on recommendations that make the most sense right now (${clientHour}:00 on ${dayOfWeek})
      3. AUTHENTIC EXPERIENCE: Include at least one local/authentic/"hidden gem" recommendation
      4. QUALITY: Prioritize highly-rated and well-reviewed places
      5. ACCESSIBILITY: Consider places that would be reasonably accessible
      6. USER INTERESTS: ${intent ? `Focus on ${intent}-related activities that make sense at this time` : 'Provide a diverse mix of activities'}

      For each recommendation, include:
      - name: The exact place name as it would appear on Google Maps
      - description: Brief enticing description (30-40 words)
      - category: Specific category (museum, restaurant, park, viewpoint, etc.)
      - whyPerfect: Why this is perfect for ${clientHour}:00 (${timeOfDay}) specifically
      - bestTimeToVisit: Time range (must include current time: ${clientHour}:00)
      - estimatedTimeNeeded: Typical visit duration (e.g., "30-45 minutes", "1-2 hours")
      - coordinates: If known, otherwise omit

      Format your response as a clean JSON array of objects. 
      Return ONLY the valid JSON array with no additional text, explanation, or markdown.
    `;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    // Extract JSON array from the response
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (!jsonMatch) {
      console.error('Failed to parse Gemini response as JSON for perfect recommendations');
      return [];
    }

    let recommendations = JSON.parse(jsonMatch[0]) as PerfectRecommendation[];

    // Enhance recommendations with Google Places data (photos, place_id)
    recommendations = await enhanceRecommendationsWithPlaceDetails(recommendations, location);

    // Calculate relevance scores for each recommendation
    const scoredRecommendations = recommendations.map(rec => {
      const scores = calculateRelevanceScore(rec, userContext, userPreferences);
      return { 
        recommendation: rec, 
        score: scores.totalScore 
      };
    });

    // Sort by score (highest first)
    scoredRecommendations.sort((a, b) => b.score - a.score);

    // Extract just the recommendations, now sorted by relevance
    const finalRecommendations = scoredRecommendations.map(item => item.recommendation);

    // Cache the recommendations for 2 hours
    await cacheService.set(cacheKey, finalRecommendations, 7200); // Cache for 2 hours

    return finalRecommendations;
  } catch (error) {
    console.error('Error generating perfect recommendations:', error);
    return [];
  }
}

// Helper function to add photos and place IDs to recommendations
async function enhanceRecommendationsWithPlaceDetails(
  recommendations: PerfectRecommendation[],
  location: LocationInfo
): Promise<PerfectRecommendation[]> {
  if (!GOOGLE_MAPS_API_KEY) {
    console.warn('Missing Google Maps API key - cannot fetch place details');
    return recommendations;
  }

  const enhanced = await Promise.all(
    recommendations.map(async (recommendation) => {
      try {
        // Find the place in Google Maps
        const placeResponse = await googleMapsClient.findPlaceFromText({
          params: {
            input: `${recommendation.name} ${location.city}`,
            inputtype: PlaceInputType.textQuery,
            fields: ['place_id', 'photos', 'formatted_address', 'name', 'rating', 'user_ratings_total', 'geometry'],
            locationbias: `circle:15000@${location.lat},${location.lng}`,
            key: GOOGLE_MAPS_API_KEY
          }
        });

        const candidates = placeResponse.data.candidates || [];

        if (candidates.length > 0) {
          const place = candidates[0];
          console.log('Found place:', place.name);
          console.log('Place photos:', place.photos);

          // Get the first photo reference if available
          const photoReference = place.photos?.[0]?.photo_reference;
          console.log('Extracted photo reference:', photoReference);
          const rating = place.rating;
          const totalRatings = place.user_ratings_total;
          
          // Extract coordinates if available
          let coordinates = undefined;
          if (place.geometry?.location) {
            coordinates = {
              lat: place.geometry.location.lat,
              lng: place.geometry.location.lng
            };
            console.log('Place coordinates:', coordinates);
          }

          return {
            ...recommendation,
            placeId: place.place_id,
            photoReference: photoReference || undefined,
            rating,
            totalRatings,
            coordinates
          };
        }

        return recommendation;
      } catch (error) {
        console.error(`Error enhancing recommendation "${recommendation.name}":`, error);
        return recommendation;
      }
    })
  );

  return enhanced;
}

/**
 * Generate travel tips for a specific location
 */
export async function getTravelTipsForLocation(location: LocationInfo): Promise<string[]> {
  try {
    const prompt = `
      Provide 3 practical travel tips for someone visiting ${location.city}, ${location.country}.
      These should be helpful, specific advice about local customs, transportation, costs, safety, or essential experiences.
      Format each tip as a complete sentence. Return only a JSON array of strings, with no additional text.
    `;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    // Extract JSON array from the response
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]) as string[];
    }

    // If parsing fails, extract tips from text
    const lines = text.split('\n').filter(line => line.trim().length > 0);
    if (lines.length > 0) {
      return lines.slice(0, 3);
    }

    return [];
  } catch (error) {
    console.error('Error generating travel tips:', error);
    return [];
  }
}