import { GoogleGenerativeAI } from "@google/generative-ai";
import fetch from "node-fetch";
import { cacheService } from "./cacheService";

// Initialize the Google Generative AI client
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY || "");
const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

// In-memory cache for place data to reduce API calls and improve performance
const placeCache: Record<string, any> = {};

// Cache duration for places (24 hours in seconds)
const PLACE_CACHE_TTL = 86400;

/**
 * Helper function to search for real places using Google Maps API
 * Includes caching to avoid duplicate API calls
 */
async function searchForPlace(activityName: string, destination: string): Promise<any | null> {
  try {
    if (!GOOGLE_MAPS_API_KEY) {
      console.log("Missing Google Maps API key, skipping place lookup");
      return null;
    }
    
    // Skip hypothetical places
    if (activityName.toLowerCase().includes('hypothetical')) {
      console.log(`Skipping hypothetical place: "${activityName}"`);
      return null;
    }
    
    // Create a cache key based on activity name and destination
    const cacheKey = `place_search:${activityName.toLowerCase().trim()}:${destination.toLowerCase().trim()}`;
    
    // Check in-memory cache first (fastest)
    if (placeCache[cacheKey]) {
      console.log(`Using cached place data for "${activityName}" (in-memory)`);
      return placeCache[cacheKey];
    }
    
    // Then check Redis cache
    const cachedResult = await cacheService.get(cacheKey);
    if (cachedResult) {
      console.log(`Using cached place data for "${activityName}" (Redis)`);
      // Update in-memory cache as well
      placeCache[cacheKey] = cachedResult;
      return cachedResult;
    }
    
    // Create a more specific search query based on activity name and destination
    const searchQuery = `${activityName} ${destination}`;
    console.log(`Searching for real place data: "${searchQuery}"`);
    
    // Make request to Google Maps Places API
    const encodedQuery = encodeURIComponent(searchQuery);
    const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodedQuery}&key=${GOOGLE_MAPS_API_KEY}`;
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Google Maps API error: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Check if we got any results
    if (data.results && data.results.length > 0) {
      const place = data.results[0];
      console.log(`Found place: ${place.name}`);
      
      // Collect photo references if available
      let photoReferences: string[] = [];
      if (place.photos && place.photos.length > 0) {
        console.log("Place photos:", place.photos);
        photoReferences = place.photos.map((photo: any) => photo.photo_reference);
        console.log("Extracted photo reference:", photoReferences[0]);
      }
      
      // Get additional place details for more info
      let openNow = undefined;
      
      // Try to get more details using the Places Details API if we have a place ID
      if (place.place_id) {
        try {
          const detailsUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${place.place_id}&fields=opening_hours&key=${GOOGLE_MAPS_API_KEY}`;
          const detailsResponse = await fetch(detailsUrl);
          const detailsData = await detailsResponse.json();
          
          if (detailsData.result && detailsData.result.opening_hours) {
            openNow = detailsData.result.opening_hours.open_now;
          }
        } catch (detailsError) {
          console.error("Error fetching place details:", detailsError);
          // Continue without details data
        }
      }
      
      const placeData = {
        placeId: place.place_id,
        name: place.name,
        formattedAddress: place.formatted_address,
        location: place.geometry?.location,
        photoReference: photoReferences[0] || null,
        photoReferences: photoReferences,
        rating: place.rating,
        userRatingsTotal: place.user_ratings_total,
        types: place.types || [],
        openNow: openNow
      };
      
      // Cache the result both in memory and Redis
      placeCache[cacheKey] = placeData;
      await cacheService.set(cacheKey, placeData, PLACE_CACHE_TTL);
      
      return placeData;
    }
    
    console.log("No place found for:", searchQuery);
    return null;
  } catch (error) {
    console.error("Error searching for place:", error);
    return null;
  }
}

// Function to enhance a single activity with place data
export async function enhanceActivityWithPlaceData(activity: ItineraryActivity, destination: string): Promise<void> {
  try {
    // If activity already has a placeId, use it directly
    if (activity.placeId) {
      // Create a cache key for this specific place ID
      const cacheKey = `place_details:${activity.placeId}`;
      let placeData;
      
      // Check cache first
      const cachedPlace = await cacheService.get(cacheKey);
      if (cachedPlace) {
        console.log(`Using cached details for place ID: ${activity.placeId}`);
        placeData = cachedPlace;
      } else if (GOOGLE_MAPS_API_KEY) {
        // Fetch place details using the Places API
        console.log(`Fetching details for place ID: ${activity.placeId}`);
        try {
          const detailsUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${activity.placeId}&fields=name,formatted_address,geometry,photos,rating,user_ratings_total,types,opening_hours&key=${GOOGLE_MAPS_API_KEY}`;
          const response = await fetch(detailsUrl);
          
          if (!response.ok) {
            throw new Error(`Google Maps API error: ${response.status}`);
          }
          
          const data = await response.json();
          
          if (data.status === "OK" && data.result) {
            placeData = {
              placeId: activity.placeId,
              name: data.result.name,
              formattedAddress: data.result.formatted_address,
              location: data.result.geometry?.location,
              photoReferences: data.result.photos?.map((photo: any) => photo.photo_reference) || [],
              photoReference: data.result.photos?.[0]?.photo_reference,
              rating: data.result.rating,
              userRatingsTotal: data.result.user_ratings_total,
              types: data.result.types,
              openNow: data.result.opening_hours?.open_now
            };
            
            // Cache this place data
            await cacheService.set(cacheKey, placeData, PLACE_CACHE_TTL);
          }
        } catch (detailsError) {
          console.error(`Error fetching details for place ID ${activity.placeId}:`, detailsError);
          // Will fall back to search by name
        }
      }
      
      if (placeData) {
        // Enhance activity with place data
        if (!activity.name || activity.name === '') activity.name = placeData.name;
        activity.formattedAddress = placeData.formattedAddress;
        activity.coordinates = placeData.location;
        activity.photoReference = placeData.photoReference;
        activity.photoReferences = placeData.photoReferences;
        activity.rating = placeData.rating;
        activity.userRatingsTotal = placeData.userRatingsTotal;
        activity.types = placeData.types;
        activity.openNow = placeData.openNow;
        
        // If the activity doesn't have a proper location, use the formatted address
        if (!activity.location || activity.location === destination) {
          activity.location = placeData.formattedAddress;
        }
        
        console.log(`Enhanced activity "${activity.name}" with place data from placeId`);
        return;
      }
    }
    
    // If we get here, either we don't have a placeId or we couldn't use it
    // So fall back to searching by name
    const placeData = await searchForPlace(activity.name, destination);
    
    if (placeData) {
      // Enhance activity with place data
      activity.placeId = placeData.placeId;
      activity.formattedAddress = placeData.formattedAddress;
      activity.coordinates = placeData.location;
      activity.photoReference = placeData.photoReference;
      activity.photoReferences = placeData.photoReferences;
      activity.rating = placeData.rating;
      activity.userRatingsTotal = placeData.userRatingsTotal;
      activity.types = placeData.types;
      activity.openNow = placeData.openNow;
      
      // If the activity doesn't have a proper location, use the formatted address
      if (!activity.location || activity.location === destination) {
        activity.location = placeData.formattedAddress;
      }
      
      console.log(`Enhanced activity "${activity.name}" with place data from search`);
    } else {
      console.log(`Could not find place data for activity "${activity.name}"`);
    }
  } catch (error) {
    console.error(`Error enhancing activity "${activity.name}":`, error);
    throw error;
  }
}

// Function to enhance all activities in an itinerary with real place data
async function enhanceActivitiesWithPlaceData(itinerary: CompleteItinerary, destination: string): Promise<void> {
  if (!itinerary.days || itinerary.days.length === 0) {
    console.log("No days found in itinerary, skipping place data enhancement");
    return;
  }
  
  const activityPromises: Promise<void>[] = [];
  
  // Process each day
  for (const day of itinerary.days) {
    if (!day.activities || day.activities.length === 0) continue;
    
    // Process each activity
    for (const activity of day.activities) {
      // Skip activities that already have place data
      if (activity.placeId) continue;
      
      const promise = (async () => {
        try {
          await enhanceActivityWithPlaceData(activity, destination);
        } catch (error) {
          console.error(`Error enhancing activity "${activity.name}":`, error);
        }
      })();
      
      activityPromises.push(promise);
    }
  }
  
  // Wait for all activity enhancements to complete (limit concurrency to avoid rate limiting)
  const BATCH_SIZE = 3;
  for (let i = 0; i < activityPromises.length; i += BATCH_SIZE) {
    const batch = activityPromises.slice(i, i + BATCH_SIZE);
    await Promise.all(batch);
    
    // Add a small delay between batches to avoid rate limiting
    if (i + BATCH_SIZE < activityPromises.length) {
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }
  
  console.log(`Enhanced ${activityPromises.length} activities with place data`);
}

// Types for itinerary generation
export interface ItineraryGenerationParams {
  destination: string;
  startDate: string;
  endDate: string;
  travelers: number;
  adventureLevel: string;
  budgetRange: string;
  paceLevel: string;
  selectedActivities: string[];
  photoReference?: string | null;
}

export interface ItineraryTravelTip {
  tip: string;
}

export interface ItineraryHighlight {
  name: string;
  description?: string;
}

export interface ItineraryOverview {
  summary: string;
  culturalHighlights: ItineraryHighlight[];
  diningExperiences: ItineraryHighlight[];
  uniqueExperiences: ItineraryHighlight[];
  travelTips: ItineraryTravelTip[];
}

export interface ItineraryActivity {
  time: string;
  name: string;
  description: string;
  location?: string;
  price?: string;
  category?: string;
  isFree?: boolean;
  // Enhanced place data from Google Maps API
  placeId?: string;
  formattedAddress?: string;
  coordinates?: { lat: number; lng: number };
  photoReference?: string;
  photoReferences?: string[];
  rating?: number;
  userRatingsTotal?: number;
  types?: string[];
  openNow?: boolean;
}

export interface ItineraryDay {
  date: string;
  dayNumber: number;
  activities: ItineraryActivity[];
}

export interface CompleteItinerary {
  destination: string;
  startDate: string;
  endDate: string;
  duration: number;
  overview: ItineraryOverview;
  days: ItineraryDay[];
  photoReference?: string | null;
}

// Generate a complete itinerary using Gemini API
// Calculate distance between two points using the Haversine formula
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  // Radius of the earth in km
  const R = 6371;
  
  // Convert degrees to radians
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  
  // Haversine formula
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2)
    ; 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)); 
  const distance = R * c; // Distance in km
  
  return distance;
}

// Group activities by proximity and optimize itinerary
function optimizeActivitiesByProximity(activities: ItineraryActivity[]): ItineraryActivity[] {
  // Filter activities that have coordinates
  const activitiesWithCoordinates = activities.filter(a => a.coordinates && a.coordinates.lat && a.coordinates.lng);
  const activitiesWithoutCoordinates = activities.filter(a => !a.coordinates || !a.coordinates.lat || !a.coordinates.lng);
  
  if (activitiesWithCoordinates.length <= 1) {
    // Not enough activities with coordinates to cluster
    return activities;
  }
  
  // Create a distance matrix between all activities
  const distanceMatrix: number[][] = [];
  for (let i = 0; i < activitiesWithCoordinates.length; i++) {
    distanceMatrix[i] = [];
    const act1 = activitiesWithCoordinates[i];
    for (let j = 0; j < activitiesWithCoordinates.length; j++) {
      const act2 = activitiesWithCoordinates[j];
      
      if (i === j) {
        distanceMatrix[i][j] = 0; // Distance to self is 0
      } else {
        // Calculate distance between the two activities
        const distance = calculateDistance(
          act1.coordinates!.lat, 
          act1.coordinates!.lng, 
          act2.coordinates!.lat, 
          act2.coordinates!.lng
        );
        distanceMatrix[i][j] = distance;
      }
    }
  }
  
  // Implement a nearest neighbor algorithm to order activities
  const visited: boolean[] = new Array(activitiesWithCoordinates.length).fill(false);
  const optimizedIndices: number[] = [];
  
  // Start with the first activity (arbitrary starting point)
  let currentIndex = 0;
  visited[currentIndex] = true;
  optimizedIndices.push(currentIndex);
  
  // Find nearest unvisited activity for each step
  while (optimizedIndices.length < activitiesWithCoordinates.length) {
    let minDistance = Infinity;
    let nearestIndex = -1;
    
    for (let i = 0; i < activitiesWithCoordinates.length; i++) {
      if (!visited[i] && distanceMatrix[currentIndex][i] < minDistance) {
        minDistance = distanceMatrix[currentIndex][i];
        nearestIndex = i;
      }
    }
    
    if (nearestIndex !== -1) {
      currentIndex = nearestIndex;
      visited[currentIndex] = true;
      optimizedIndices.push(currentIndex);
    } else {
      // No more unvisited activities (shouldn't happen, but just in case)
      break;
    }
  }
  
  // Reorder activities based on optimized indices
  const optimizedActivities = optimizedIndices.map(index => activitiesWithCoordinates[index]);
  
  // Add activities without coordinates at the end (we can't optimize their placement)
  return [...optimizedActivities, ...activitiesWithoutCoordinates];
}

// Adjust activity times based on their order and distribute throughout the day
function distributeActivityTimes(activities: ItineraryActivity[]): ItineraryActivity[] {
  if (activities.length <= 1) return activities;
  
  // Define reasonable start and end times for a day (8:00 to 20:00)
  const startHour = 8;
  const endHour = 20;
  const totalHours = endHour - startHour;
  
  // Calculate time gaps
  const timeGap = totalHours / (activities.length - 1);
  
  // Assign new times to activities based on their order
  return activities.map((activity, index) => {
    const hour = Math.floor(startHour + index * timeGap);
    const minute = Math.round((timeGap * index - Math.floor(timeGap * index)) * 60);
    
    const formattedHour = hour.toString().padStart(2, '0');
    const formattedMinute = minute.toString().padStart(2, '0');
    
    return {
      ...activity,
      time: `${formattedHour}:${formattedMinute}`
    };
  });
}

export async function generateItinerary(params: ItineraryGenerationParams): Promise<CompleteItinerary> {
  try {
    // Calculate trip duration
    const start = new Date(params.startDate);
    const end = new Date(params.endDate);
    const duration = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    
    if (duration <= 0) {
      throw new Error("End date must be after start date");
    }
    
    // Define activities based on selected preferences
    const activityDescriptions = {
      cultural: "museums, historical sites, landmarks, local traditions, and cultural experiences",
      culinary: "restaurants, food tours, cooking classes, local cuisine, markets, and food experiences",
      entertainment: "shows, performances, nightlife, concerts, theater, and entertainment venues",
      outdoor: "parks, hiking, nature activities, beaches, adventure sports, and outdoor experiences",
      shopping: "markets, boutiques, malls, artisan shops, and shopping districts"
    };
    
    // Create activity description string
    const activityPreferences = params.selectedActivities.map(act => 
      `${act} (${activityDescriptions[act as keyof typeof activityDescriptions]})`
    ).join(", ");
    
    // Determine number of daily activities based on pace level
    let activitiesPerDay = 4; // Default for moderate pace
    if (params.paceLevel === 'relaxed') {
      activitiesPerDay = 3;
    } else if (params.paceLevel === 'intense') {
      activitiesPerDay = 6;
    }
    
    // Construct the prompt for Gemini
    const prompt = `
    As a professional travel planner, create a detailed ${duration}-day travel itinerary for a trip to ${params.destination}.
    
    TRIP DETAILS:
    - Destination: ${params.destination}
    - Travel Dates: ${new Date(params.startDate).toLocaleDateString()} to ${new Date(params.endDate).toLocaleDateString()} (${duration} days)
    - Number of Travelers: ${params.travelers}
    - Adventure Level: ${params.adventureLevel} (on a scale of low, medium, high)
    - Budget Range: ${params.budgetRange} (budget, mid-range, or luxury)
    - Pace Level: ${params.paceLevel} (relaxed, moderate, or intense)
    - Activity Preferences: ${activityPreferences || "All types of activities"}
    
    CREATE A COMPREHENSIVE ITINERARY WITH:
    
    1. OVERVIEW SECTION that includes:
       - A summary paragraph that captures the essence of this adventure (100-150 words)
       - Cultural Highlights: 4-5 key cultural attractions or experiences
       - Dining Experiences: 4-5 notable dining recommendations 
       - Unique Experiences: 4-5 special activities that make this trip memorable
       - Travel Tips: 4-5 practical tips specific to this destination
    
    2. DETAILED DAY-BY-DAY ITINERARY:
       - Create a complete schedule for EACH of the ${duration} days
       - EVERY day MUST have EXACTLY ${activitiesPerDay} activities based on the ${params.paceLevel} pace
       - Each activity should include:
         * Time (format: "HH:MM" using 24-hour clock)
         * Name of the specific place or activity
         * Brief description (1-2 sentences)
         * Full address or location
         * Approximate price range (free, $, $$, $$$)
         * Activity category (cultural, culinary, entertainment, outdoor, shopping, adventure, relaxation)
         * Whether the activity is free (true/false)
       - Schedule activities from morning to evening with reasonable time gaps
       - Include famous landmarks and popular attractions specific to ${params.destination}
       - Incorporate all the preferred activity types: ${params.selectedActivities.join(", ")}
       - Match recommendations with the ${params.budgetRange} budget range
    
    Format the response as a complete, structured JSON object following this exact template:
    {
      "destination": "Destination Name",
      "startDate": "YYYY-MM-DD",
      "endDate": "YYYY-MM-DD",
      "duration": number of days,
      "overview": {
        "summary": "Summary text...",
        "culturalHighlights": [{"name": "Name", "description": "Description"}],
        "diningExperiences": [{"name": "Name", "description": "Description"}],
        "uniqueExperiences": [{"name": "Name", "description": "Description"}],
        "travelTips": [{"tip": "Tip text..."}]
      },
      "days": [
        {
          "date": "YYYY-MM-DD",
          "dayNumber": 1,
          "activities": [
            {
              "time": "09:00",
              "name": "Activity Name",
              "description": "Description",
              "location": "Full address or location",
              "price": "$" ($ = budget, $$ = mid-range, $$$ = luxury),
              "category": "one of: cultural/culinary/entertainment/outdoor/shopping/adventure/relaxation",
              "isFree": boolean
            }
          ]
        }
      ]
    }
    
    CRITICALLY IMPORTANT REQUIREMENTS:
    1. Generate EXACTLY ${duration} days in the itinerary (from day 1 to day ${duration})
    2. EVERY day MUST have EXACTLY ${activitiesPerDay} activities (no more, no less)
    3. All activities must be real places with specific names and addresses in ${params.destination}
    4. Include famous landmarks and must-see attractions of ${params.destination}
    5. For "location" field, provide full address or specific location description
    6. For "time" field, use 24-hour format (e.g., "09:00", "14:30")
    7. For "price" field, use "$" for budget options, "$$" for mid-range, and "$$$" for luxury
    8. Return ONLY a valid, well-formed JSON object with no additional text
    `;
    
    // Send the prompt to Gemini API
    console.log("Sending itinerary generation prompt to Gemini API...");
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    // Parse the JSON response
    try {
      // Extract the JSON from the text in case there are extra tokens
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error("Could not extract valid JSON from the response");
      }
      
      const itinerary = JSON.parse(jsonMatch[0]) as CompleteItinerary;
      
      // Add the photo reference from the parameters to the itinerary
      if (params.photoReference) {
        itinerary.photoReference = params.photoReference;
      }
      
      // Ensure all days have the correct number of activities based on pace
      if (itinerary.days) {
        // Verify we have the expected number of days
        if (itinerary.days.length < duration) {
          console.log(`Adding missing days. Got ${itinerary.days.length}, expected ${duration}`);
          
          // Create missing days
          const startDateObj = new Date(params.startDate);
          for (let i = itinerary.days.length; i < duration; i++) {
            const currentDate = new Date(startDateObj);
            currentDate.setDate(startDateObj.getDate() + i);
            const formattedDate = currentDate.toISOString().split('T')[0]; // YYYY-MM-DD
            
            // Create activities for this day
            const activities: ItineraryActivity[] = [];
            for (let j = 0; j < activitiesPerDay; j++) {
              const hour = 9 + Math.floor(j * (10 / activitiesPerDay));
              const hourStr = hour.toString().padStart(2, '0');
              
              const activity: ItineraryActivity = {
                time: `${hourStr}:00`,
                name: `${params.destination} Activity ${j+1}`,
                description: `Explore attractions in ${params.destination} on day ${i+1}`,
                location: `${params.destination}`,
                price: params.budgetRange === 'budget' ? '$' : params.budgetRange === 'luxury' ? '$$$' : '$$',
                category: params.selectedActivities[j % params.selectedActivities.length] || 'cultural',
                isFree: j % 3 === 0
              };
              activities.push(activity);
            }
            
            // Add this day to the itinerary
            itinerary.days.push({
              date: formattedDate,
              dayNumber: i + 1,
              activities
            });
          }
        }
        
        // Check each day has the correct number of activities
        itinerary.days.forEach(day => {
          if (!day.activities || day.activities.length < activitiesPerDay) {
            console.log(`Fixing day ${day.dayNumber}: Adding missing activities. Got ${day.activities?.length || 0}, expected ${activitiesPerDay}`);
            
            // Create or initialize activities array if needed
            if (!day.activities) day.activities = [];
            
            // Add missing activities
            const neededActivities = activitiesPerDay - day.activities.length;
            for (let i = 0; i < neededActivities; i++) {
              const existingCount = day.activities.length;
              const hour = 9 + Math.floor((existingCount + i) * (10 / activitiesPerDay));
              const hourStr = hour.toString().padStart(2, '0');
              
              const activity: ItineraryActivity = {
                time: `${hourStr}:00`,
                name: `${params.destination} Activity ${existingCount + i + 1}`,
                description: `Explore ${params.destination} attractions`,
                location: `${params.destination}`,
                price: params.budgetRange === 'budget' ? '$' : params.budgetRange === 'luxury' ? '$$$' : '$$',
                category: params.selectedActivities[(existingCount + i) % params.selectedActivities.length] || 'cultural',
                isFree: (existingCount + i) % 3 === 0
              };
              day.activities.push(activity);
            }
          } else if (day.activities.length > activitiesPerDay) {
            // Trim excess activities
            console.log(`Fixing day ${day.dayNumber}: Trimming excess activities. Got ${day.activities?.length}, expected ${activitiesPerDay}`);
            day.activities = day.activities.slice(0, activitiesPerDay);
          }
        });
        
        // Sort days by day number
        itinerary.days.sort((a, b) => a.dayNumber - b.dayNumber);
        
        // Enhance activities with real place data
        console.log("Enhancing activities with real place data...");
        await enhanceActivitiesWithPlaceData(itinerary, params.destination);
        
        // Optimize activities by proximity for each day
        for (const day of itinerary.days) {
          if (day.activities && day.activities.length > 1) {
            console.log(`Optimizing activities by proximity for day ${day.dayNumber}`);
            
            // First optimize the order by proximity
            day.activities = optimizeActivitiesByProximity(day.activities);
            
            // Then redistribute times based on the new order
            day.activities = distributeActivityTimes(day.activities);
            
            console.log(`Optimized ${day.activities.length} activities for day ${day.dayNumber}`);
          }
        }
      }
      
      return itinerary;
    } catch (error) {
      console.error("Error parsing itinerary JSON:", error);
      console.error("Raw response text:", text);
      throw new Error("Failed to parse the generated itinerary");
    }
  } catch (error) {
    console.error("Error generating itinerary:", error);
    throw error;
  }
}