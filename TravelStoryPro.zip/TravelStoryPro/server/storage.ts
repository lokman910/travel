import {
  users, trips, stories, activities, places, collections,
  type User, type InsertUser,
  type Trip, type InsertTrip,
  type Story, type InsertStory,
  type Activity, type InsertActivity,
  type Place, type InsertPlace,
  type Collection, type InsertCollection
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Trip methods
  getTrip(id: number): Promise<Trip | undefined>;
  getUserTrips(userId: number): Promise<Trip[]>;
  createTrip(trip: InsertTrip): Promise<Trip>;
  updateTrip(id: number, trip: Partial<Trip>): Promise<Trip | undefined>;
  deleteTrip(id: number): Promise<boolean>;
  
  // Story methods
  getStory(id: number): Promise<Story | undefined>;
  getUserStories(userId: number): Promise<Story[]>;
  getDiscoveryFeed(): Promise<Story[]>;
  createStory(story: InsertStory): Promise<Story>;
  updateStory(id: number, story: Partial<Story>): Promise<Story | undefined>;
  deleteStory(id: number): Promise<boolean>;
  
  // Activity methods
  getActivities(tripId: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  updateActivity(id: number, activity: Partial<Activity>): Promise<Activity | undefined>;
  deleteActivity(id: number): Promise<boolean>;
  
  // Place methods
  getPlace(id: number): Promise<Place | undefined>;
  getUserPlaces(userId: number): Promise<Place[]>;
  getTripPlaces(tripId: number): Promise<Place[]>;
  createPlace(place: InsertPlace): Promise<Place>;
  deletePlace(id: number): Promise<boolean>;
  
  // Collection methods
  getCollection(id: number): Promise<Collection | undefined>;
  getUserCollections(userId: number): Promise<Collection[]>;
  createCollection(collection: InsertCollection): Promise<Collection>;
  updateCollection(id: number, collection: Partial<Collection>): Promise<Collection | undefined>;
  deleteCollection(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private trips: Map<number, Trip>;
  private stories: Map<number, Story>;
  private activities: Map<number, Activity>;
  private places: Map<number, Place>;
  private collections: Map<number, Collection>;
  
  private userIdCounter: number;
  private tripIdCounter: number;
  private storyIdCounter: number;
  private activityIdCounter: number;
  private placeIdCounter: number;
  private collectionIdCounter: number;

  constructor() {
    this.users = new Map();
    this.trips = new Map();
    this.stories = new Map();
    this.activities = new Map();
    this.places = new Map();
    this.collections = new Map();
    
    this.userIdCounter = 1;
    this.tripIdCounter = 1;
    this.storyIdCounter = 1;
    this.activityIdCounter = 1;
    this.placeIdCounter = 1;
    this.collectionIdCounter = 1;
    
    // Initialize with some sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create a sample user
    const user: User = {
      id: this.userIdCounter++,
      username: "emma",
      password: "password", // In real app, this would be hashed
      displayName: "Emma Wilson",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
      bio: "Travel enthusiast",
      countriesVisited: 28
    };
    this.users.set(user.id, user);
    
    // Create sample trips
    const parisTrip: Trip = {
      id: this.tripIdCounter++,
      userId: user.id,
      title: "Paris Getaway",
      destination: "Paris, France",
      coverImage: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34",
      startDate: new Date("2023-10-15"),
      endDate: new Date("2023-10-22"),
      status: "in-progress",
      itinerary: {}
    };
    
    const tokyoTrip: Trip = {
      id: this.tripIdCounter++,
      userId: user.id,
      title: "Tokyo Exploration",
      destination: "Tokyo, Japan",
      coverImage: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e",
      startDate: new Date("2023-12-01"),
      endDate: new Date("2023-12-15"),
      status: "upcoming",
      itinerary: {}
    };
    
    const swissTrip: Trip = {
      id: this.tripIdCounter++,
      userId: user.id,
      title: "Swiss Alps Adventure",
      destination: "Swiss Alps, Switzerland",
      coverImage: "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1",
      startDate: new Date("2024-01-05"),
      endDate: new Date("2024-01-12"),
      status: "draft",
      itinerary: {}
    };
    
    this.trips.set(parisTrip.id, parisTrip);
    this.trips.set(tokyoTrip.id, tokyoTrip);
    this.trips.set(swissTrip.id, swissTrip);
    
    // Create sample activities for Paris trip
    const activities = [
      {
        id: this.activityIdCounter++,
        tripId: parisTrip.id,
        day: 1,
        type: "flight",
        title: "Arrive at Charles de Gaulle Airport",
        time: "10:30 AM",
        location: "Terminal 2E, Air France Flight AF1234",
        notes: ""
      },
      {
        id: this.activityIdCounter++,
        tripId: parisTrip.id,
        day: 1,
        type: "hotel",
        title: "Check-in at Hotel Le Marais",
        time: "2:00 PM",
        location: "21 Rue des Archives, 75004 Paris",
        notes: ""
      },
      {
        id: this.activityIdCounter++,
        tripId: parisTrip.id,
        day: 1,
        type: "restaurant",
        title: "Dinner at Le Petit Bistro",
        time: "7:30 PM",
        location: "15 Rue Saint-Denis, 75001 Paris",
        notes: ""
      },
      {
        id: this.activityIdCounter++,
        tripId: parisTrip.id,
        day: 2,
        type: "museum",
        title: "Louvre Museum",
        time: "9:00 AM",
        location: "Rue de Rivoli, 75001 Paris",
        notes: ""
      },
      {
        id: this.activityIdCounter++,
        tripId: parisTrip.id,
        day: 2,
        type: "restaurant",
        title: "Lunch at Café Marly",
        time: "1:00 PM",
        location: "93 Rue de Rivoli, 75001 Paris",
        notes: ""
      },
      {
        id: this.activityIdCounter++,
        tripId: parisTrip.id,
        day: 2,
        type: "tour",
        title: "Seine River Cruise",
        time: "5:00 PM",
        location: "Port de la Bourdonnais, 75007 Paris",
        notes: ""
      }
    ];
    
    activities.forEach(activity => {
      this.activities.set(activity.id, activity);
    });
    
    // Create sample stories
    const parisStory: Story = {
      id: this.storyIdCounter++,
      userId: user.id,
      tripId: null,
      title: "3 Days in Paris",
      location: "Paris, France",
      coverImage: "https://images.unsplash.com/photo-1523906834658-6e24ef2386f9",
      content: "Explored the charming streets of Paris, discovered hidden cafés, and caught the sunset from the Eiffel Tower...",
      photos: ["https://images.unsplash.com/photo-1523906834658-6e24ef2386f9"],
      createdAt: new Date("2023-04-15"),
      likes: 286,
      comments: 24
    };
    
    const baliStory: Story = {
      id: this.storyIdCounter++,
      userId: user.id,
      tripId: null,
      title: "Bali Adventure Week",
      location: "Bali, Indonesia",
      coverImage: "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2",
      content: "Stunning beaches, lush rice terraces, and spiritual experiences. Bali offered the perfect balance of adventure and relaxation...",
      photos: ["https://images.unsplash.com/photo-1518548419970-58e3b4079ab2"],
      createdAt: new Date("2023-05-20"),
      likes: 452,
      comments: 37
    };
    
    const barcelonaStory: Story = {
      id: this.storyIdCounter++,
      userId: user.id,
      tripId: null,
      title: "Barcelona Weekend",
      location: "Barcelona, Spain",
      coverImage: "https://images.unsplash.com/photo-1543832923-44667a44c804",
      content: "A weekend exploring Gaudi's architecture and enjoying tapas...",
      photos: ["https://images.unsplash.com/photo-1543832923-44667a44c804"],
      createdAt: new Date("2023-06-10"),
      likes: 185,
      comments: 12
    };
    
    const nycStory: Story = {
      id: this.storyIdCounter++,
      userId: user.id,
      tripId: null,
      title: "New York City",
      location: "New York, USA",
      coverImage: "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b",
      content: "Exploring the Big Apple's iconic landmarks and vibrant neighborhoods...",
      photos: ["https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b"],
      createdAt: new Date("2023-05-05"),
      likes: 210,
      comments: 18
    };
    
    const baliBeachesStory: Story = {
      id: this.storyIdCounter++,
      userId: user.id,
      tripId: null,
      title: "Bali Beaches",
      location: "Bali, Indonesia",
      coverImage: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
      content: "Exploring the most beautiful beaches in Bali...",
      photos: ["https://images.unsplash.com/photo-1507525428034-b723cf961d3e"],
      createdAt: new Date("2023-04-15"),
      likes: 320,
      comments: 28
    };
    
    const italyStory: Story = {
      id: this.storyIdCounter++,
      userId: user.id,
      tripId: null,
      title: "Italian Adventure",
      location: "Italy",
      coverImage: "https://images.unsplash.com/photo-1516483638261-f4dbaf036963",
      content: "From Rome to Venice, exploring Italy's rich culture and cuisine...",
      photos: ["https://images.unsplash.com/photo-1516483638261-f4dbaf036963"],
      createdAt: new Date("2023-03-10"),
      likes: 275,
      comments: 22
    };
    
    this.stories.set(parisStory.id, parisStory);
    this.stories.set(baliStory.id, baliStory);
    this.stories.set(barcelonaStory.id, barcelonaStory);
    this.stories.set(nycStory.id, nycStory);
    this.stories.set(baliBeachesStory.id, baliBeachesStory);
    this.stories.set(italyStory.id, italyStory);
    
    // Create a sample place
    const place: Place = {
      id: this.placeIdCounter++,
      userId: user.id,
      tripId: parisTrip.id,
      name: "Café Le Marais",
      category: "food",
      address: "35 Rue des Archives, 75004 Paris, France",
      lat: "48.8589",
      lng: "2.3469",
      rating: "4.5",
      photo: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa"
    };
    
    this.places.set(place.id, place);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Trip methods
  async getTrip(id: number): Promise<Trip | undefined> {
    return this.trips.get(id);
  }

  async getUserTrips(userId: number): Promise<Trip[]> {
    return Array.from(this.trips.values()).filter(
      (trip) => trip.userId === userId
    );
  }

  async createTrip(trip: InsertTrip): Promise<Trip> {
    const id = this.tripIdCounter++;
    const newTrip: Trip = { ...trip, id };
    this.trips.set(id, newTrip);
    return newTrip;
  }

  async updateTrip(id: number, tripUpdate: Partial<Trip>): Promise<Trip | undefined> {
    const trip = this.trips.get(id);
    if (!trip) return undefined;
    
    const updatedTrip = { ...trip, ...tripUpdate };
    this.trips.set(id, updatedTrip);
    return updatedTrip;
  }

  async deleteTrip(id: number): Promise<boolean> {
    return this.trips.delete(id);
  }

  // Story methods
  async getStory(id: number): Promise<Story | undefined> {
    return this.stories.get(id);
  }

  async getUserStories(userId: number): Promise<Story[]> {
    return Array.from(this.stories.values()).filter(
      (story) => story.userId === userId
    );
  }

  async getDiscoveryFeed(): Promise<Story[]> {
    // In a real app, this would filter and sort based on user preferences, etc.
    return Array.from(this.stories.values());
  }

  async createStory(story: InsertStory): Promise<Story> {
    const id = this.storyIdCounter++;
    const newStory: Story = { 
      ...story, 
      id, 
      createdAt: new Date(),
      likes: 0,
      comments: 0
    };
    this.stories.set(id, newStory);
    return newStory;
  }

  async updateStory(id: number, storyUpdate: Partial<Story>): Promise<Story | undefined> {
    const story = this.stories.get(id);
    if (!story) return undefined;
    
    const updatedStory = { ...story, ...storyUpdate };
    this.stories.set(id, updatedStory);
    return updatedStory;
  }

  async deleteStory(id: number): Promise<boolean> {
    return this.stories.delete(id);
  }

  // Activity methods
  async getActivities(tripId: number): Promise<Activity[]> {
    return Array.from(this.activities.values()).filter(
      (activity) => activity.tripId === tripId
    );
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const newActivity: Activity = { ...activity, id };
    this.activities.set(id, newActivity);
    return newActivity;
  }

  async updateActivity(id: number, activityUpdate: Partial<Activity>): Promise<Activity | undefined> {
    const activity = this.activities.get(id);
    if (!activity) return undefined;
    
    const updatedActivity = { ...activity, ...activityUpdate };
    this.activities.set(id, updatedActivity);
    return updatedActivity;
  }

  async deleteActivity(id: number): Promise<boolean> {
    return this.activities.delete(id);
  }

  // Place methods
  async getPlace(id: number): Promise<Place | undefined> {
    return this.places.get(id);
  }

  async getUserPlaces(userId: number): Promise<Place[]> {
    return Array.from(this.places.values()).filter(
      (place) => place.userId === userId
    );
  }

  async getTripPlaces(tripId: number): Promise<Place[]> {
    return Array.from(this.places.values()).filter(
      (place) => place.tripId === tripId
    );
  }

  async createPlace(place: InsertPlace): Promise<Place> {
    const id = this.placeIdCounter++;
    const newPlace: Place = { ...place, id };
    this.places.set(id, newPlace);
    return newPlace;
  }

  async deletePlace(id: number): Promise<boolean> {
    return this.places.delete(id);
  }

  // Collection methods
  async getCollection(id: number): Promise<Collection | undefined> {
    return this.collections.get(id);
  }

  async getUserCollections(userId: number): Promise<Collection[]> {
    return Array.from(this.collections.values()).filter(
      (collection) => collection.userId === userId
    );
  }

  async createCollection(collection: InsertCollection): Promise<Collection> {
    const id = this.collectionIdCounter++;
    const newCollection: Collection = { ...collection, id };
    this.collections.set(id, newCollection);
    return newCollection;
  }

  async updateCollection(id: number, collectionUpdate: Partial<Collection>): Promise<Collection | undefined> {
    const collection = this.collections.get(id);
    if (!collection) return undefined;
    
    const updatedCollection = { ...collection, ...collectionUpdate };
    this.collections.set(id, updatedCollection);
    return updatedCollection;
  }

  async deleteCollection(id: number): Promise<boolean> {
    return this.collections.delete(id);
  }
}

export const storage = new MemStorage();
