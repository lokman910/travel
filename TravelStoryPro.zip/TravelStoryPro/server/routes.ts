/**
 * API Routes Configuration
 * This module defines all REST API endpoints for the Travel Story application
 * 
 * Route Categories:
 * - User Management (/api/user/*)
 * - Trip Planning (/api/trips/*)
 * - Story Sharing (/api/stories/*)
 * - Activity Management (/api/activities/*)
 * - Place Management (/api/places/*)
 * - Collection Management (/api/collections/*)
 * 
 * Features:
 * - Input validation using Zod schemas
 * - Proper error handling and status codes
 * - RESTful endpoint structure
 * - Type safety with TypeScript
 */

import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";  // Database operations
import { insertTripSchema, insertStorySchema, insertActivitySchema, insertPlaceSchema, insertCollectionSchema } from "@shared/schema";
import { ZodError } from "zod";  // Runtime type checking
import * as locationService from './services/locationService';
import * as recommendationService from './services/recommendationService';
import * as itineraryService from './services/itineraryService';
import type { ItineraryActivity, CompleteItinerary, ItineraryDay } from './services/itineraryService';
import { cacheService } from './services/cacheService';
import { z } from 'zod';

// Environment variables for API access
const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;

/**
 * Registers all API routes with the Express application
 * @param app Express application instance
 * @returns HTTP server instance
 */
export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  
  // User routes
  app.get("/api/user/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const user = await storage.getUser(id);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Exclude password from response
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });
  
  // Trip routes
  app.get("/api/trips", async (req, res) => {
    const userId = parseInt(req.query.userId as string);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const trips = await storage.getUserTrips(userId);
    res.json(trips);
  });
  
  app.get("/api/trips/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const trip = await storage.getTrip(id);
    
    if (!trip) {
      return res.status(404).json({ message: "Trip not found" });
    }
    
    res.json(trip);
  });
  
  app.post("/api/trips", async (req, res) => {
    try {
      const tripData = insertTripSchema.parse(req.body);
      const trip = await storage.createTrip(tripData);
      res.status(201).json(trip);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid trip data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create trip" });
    }
  });
  
  app.put("/api/trips/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const updatedTrip = await storage.updateTrip(id, req.body);
      
      if (!updatedTrip) {
        return res.status(404).json({ message: "Trip not found" });
      }
      
      res.json(updatedTrip);
    } catch (error) {
      res.status(500).json({ message: "Failed to update trip" });
    }
  });
  
  app.delete("/api/trips/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const success = await storage.deleteTrip(id);
    
    if (!success) {
      return res.status(404).json({ message: "Trip not found" });
    }
    
    res.status(204).send();
  });
  
  // Story routes
  app.get("/api/stories", async (req, res) => {
    const userId = req.query.userId ? parseInt(req.query.userId as string) : null;
    
    let stories;
    if (userId) {
      stories = await storage.getUserStories(userId);
    } else {
      stories = await storage.getDiscoveryFeed();
    }
    
    res.json(stories);
  });
  
  app.get("/api/stories/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const story = await storage.getStory(id);
    
    if (!story) {
      return res.status(404).json({ message: "Story not found" });
    }
    
    res.json(story);
  });
  
  app.post("/api/stories", async (req, res) => {
    try {
      const storyData = insertStorySchema.parse(req.body);
      const story = await storage.createStory(storyData);
      res.status(201).json(story);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid story data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create story" });
    }
  });
  
  app.put("/api/stories/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const updatedStory = await storage.updateStory(id, req.body);
      
      if (!updatedStory) {
        return res.status(404).json({ message: "Story not found" });
      }
      
      res.json(updatedStory);
    } catch (error) {
      res.status(500).json({ message: "Failed to update story" });
    }
  });
  
  app.delete("/api/stories/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const success = await storage.deleteStory(id);
    
    if (!success) {
      return res.status(404).json({ message: "Story not found" });
    }
    
    res.status(204).send();
  });
  
  // Activity routes
  app.get("/api/activities", async (req, res) => {
    const tripId = parseInt(req.query.tripId as string);
    
    if (isNaN(tripId)) {
      return res.status(400).json({ message: "Invalid trip ID" });
    }
    
    const activities = await storage.getActivities(tripId);
    res.json(activities);
  });
  
  app.post("/api/activities", async (req, res) => {
    try {
      const activityData = insertActivitySchema.parse(req.body);
      const activity = await storage.createActivity(activityData);
      res.status(201).json(activity);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid activity data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create activity" });
    }
  });
  
  app.put("/api/activities/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const updatedActivity = await storage.updateActivity(id, req.body);
      
      if (!updatedActivity) {
        return res.status(404).json({ message: "Activity not found" });
      }
      
      res.json(updatedActivity);
    } catch (error) {
      res.status(500).json({ message: "Failed to update activity" });
    }
  });
  
  app.delete("/api/activities/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const success = await storage.deleteActivity(id);
    
    if (!success) {
      return res.status(404).json({ message: "Activity not found" });
    }
    
    res.status(204).send();
  });
  
  // Place routes
  app.get("/api/places", async (req, res) => {
    const userId = req.query.userId ? parseInt(req.query.userId as string) : null;
    const tripId = req.query.tripId ? parseInt(req.query.tripId as string) : null;
    
    let places;
    if (tripId) {
      places = await storage.getTripPlaces(tripId);
    } else if (userId) {
      places = await storage.getUserPlaces(userId);
    } else {
      return res.status(400).json({ message: "Either userId or tripId is required" });
    }
    
    res.json(places);
  });
  
  app.post("/api/places", async (req, res) => {
    try {
      const placeData = insertPlaceSchema.parse(req.body);
      const place = await storage.createPlace(placeData);
      res.status(201).json(place);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid place data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create place" });
    }
  });
  
  app.delete("/api/places/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const success = await storage.deletePlace(id);
    
    if (!success) {
      return res.status(404).json({ message: "Place not found" });
    }
    
    res.status(204).send();
  });
  
  // Collection routes
  app.get("/api/collections", async (req, res) => {
    const userId = parseInt(req.query.userId as string);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const collections = await storage.getUserCollections(userId);
    res.json(collections);
  });
  
  app.post("/api/collections", async (req, res) => {
    try {
      const collectionData = insertCollectionSchema.parse(req.body);
      const collection = await storage.createCollection(collectionData);
      res.status(201).json(collection);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid collection data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create collection" });
    }
  });
  
  app.put("/api/collections/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    try {
      const updatedCollection = await storage.updateCollection(id, req.body);
      
      if (!updatedCollection) {
        return res.status(404).json({ message: "Collection not found" });
      }
      
      res.json(updatedCollection);
    } catch (error) {
      res.status(500).json({ message: "Failed to update collection" });
    }
  });
  
  app.delete("/api/collections/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const success = await storage.deleteCollection(id);
    
    if (!success) {
      return res.status(404).json({ message: "Collection not found" });
    }
    
    res.status(204).send();
  });

  // Location and exploration routes

  // Schema for validating coordinates
  const coordinatesSchema = z.object({
    lat: z.number().min(-90).max(90),
    lng: z.number().min(-180).max(180)
  });

  // Get a user's current location (from coordinates)
  app.post("/api/location/current", async (req, res) => {
    try {
      console.log("Received request to /api/location/current:", req.body);
      const { lat, lng } = coordinatesSchema.parse(req.body);
      
      // Check cache first
      const cacheKey = `location:${lat},${lng}`;
      const cachedResult = await cacheService.get(cacheKey);
      if (cachedResult) {
        console.log('Returning cached location result');
        return res.json(cachedResult);
      }
      
      // Log that we received valid coordinates
      console.log("Valid coordinates received:", { lat, lng });
      
      // Get city info from location service
      const cityInfo = await locationService.getCurrentCity({ lat, lng });
      
      // Cache the result if we got city info
      if (cityInfo) {
        await cacheService.set(`location:${lat},${lng}`, cityInfo, 86400); // Cache for 24 hours
      }
      
      // Check if city info was returned
      if (!cityInfo) {
        console.log("No city info returned from locationService");
        
        // Provide fallback response with basic information
        const fallbackInfo = {
          name: "Current Location",
          country: "Unknown",
          coordinates: { lat, lng },
          description: "Your current location"
        };
        
        console.log("Returning fallback city info:", fallbackInfo);
        return res.json(fallbackInfo);
      }
      
      console.log("Returning city info:", cityInfo);
      res.json(cityInfo);
    } catch (error) {
      console.error("Error in /api/location/current:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid coordinates", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to get current location" });
    }
  });

  // Get nearby attractions
  app.post("/api/explore/nearby", async (req, res) => {
    try {
      const { lat, lng } = coordinatesSchema.parse(req.body);
      const radius = req.body.radius ? parseInt(req.body.radius) : 5000;
      const type = req.body.type || 'tourist_attraction';
      
      const attractions = await locationService.getNearbyAttractions({ lat, lng }, radius, type);
      
      // Convert to our app's Place format
      const places = attractions.map(attraction => locationService.convertToAppPlace(attraction));
      
      res.json(places);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid coordinates", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to get nearby attractions" });
    }
  });

  // Get popular destinations near the user
  app.post("/api/explore/destinations", async (req, res) => {
    try {
      const { lat, lng } = coordinatesSchema.parse(req.body);
      const radius = req.body.radius ? parseInt(req.body.radius) : 200000; // Default 200km
      
      const destinations = await locationService.getPopularDestinations({ lat, lng }, radius);
      
      res.json(destinations);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid coordinates", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to get popular destinations" });
    }
  });

  // Get perfect AI recommendations for right now
  app.post("/api/explore/recommendations", async (req, res) => {
    try {
      const { lat, lng } = coordinatesSchema.parse(req.body);
      const city = req.body.city || '';
      const country = req.body.country || '';
      const intent = req.body.intent || null; // User's current interest
      const date = req.body.date ? new Date(req.body.date) : new Date();
      
      const recommendations = await recommendationService.getPerfectRecommendations(
        { city, country, lat, lng },
        city,
        country,
        intent,
        date
      );
      
      res.json(recommendations);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid coordinates", errors: error.errors });
      }
      console.error("Failed to get perfect recommendations:", error);
      res.status(500).json({ message: "Failed to get recommendations" });
    }
  });

  // Get Perfect for Today recommendations
  app.post("/api/explore/perfect-for-today", async (req, res) => {
    try {
      const { lat, lng } = coordinatesSchema.parse(req.body);
      const city = req.body.city || '';
      const country = req.body.country || '';
      const intent = req.body.intent || null;
      const date = req.body.date ? new Date(req.body.date) : new Date();
      
      const recommendations = await recommendationService.getPerfectRecommendations(
        { city, country, lat, lng },
        city,
        country,
        intent,
        date
      );
      
      res.json(recommendations);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid coordinates", errors: error.errors });
      }
      console.error("Error getting perfect recommendations:", error);
      res.status(500).json({ message: "Failed to get perfect recommendations" });
    }
  });

  // Get AI-generated travel tips for a location
  app.post("/api/explore/travel-tips", async (req, res) => {
    try {
      const { lat, lng } = coordinatesSchema.parse(req.body);
      const city = req.body.city || '';
      const country = req.body.country || '';
      
      const tips = await recommendationService.getTravelTipsForLocation(
        { city, country, lat, lng }
      );
      
      res.json(tips);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid coordinates", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to get travel tips" });
    }
  });
  
  // The itinerary generation endpoint is defined below

  // Proxy endpoint for Google Maps Place Photos
  // This avoids exposing the API key in client-side code
  app.get("/api/place/photo", async (req, res) => {
    try {
      console.log('Photo proxy request received:', req.query);
      const photoReference = req.query.reference;
      const maxWidth = req.query.maxwidth || 400;
      
      console.log('Photo reference:', photoReference);
      console.log('Max width:', maxWidth);
      
      if (!photoReference || typeof photoReference !== 'string') {
        return res.status(400).json({ message: "Photo reference is required" });
      }
      
      if (!GOOGLE_MAPS_API_KEY) {
        console.error("Missing Google Maps API key for place photo");
        return res.status(503).json({ message: "Maps service unavailable" });
      }
      
      // Construct the URL for Google Maps Place Photo API
      // Fixed to use the correct parameter name 'photo_reference' instead of 'photoreference'
      const photoUrl = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=${maxWidth}&photo_reference=${photoReference}&key=${GOOGLE_MAPS_API_KEY}`;
      
      // Log the photo request (without the API key)
      console.log(`Fetching photo with reference: ${photoReference.substring(0, 10)}...`);
      
      // Proxy the request to Google Maps and pipe the response back to the client
      try {
        const response = await fetch(photoUrl);
        
        if (!response.ok) {
          console.error(`Google Maps photo API error: ${response.status}, ${await response.text()}`);
          throw new Error(`Google Maps API error: ${response.status}`);
        }
        
        // Set strong caching headers for photos
        res.setHeader('Cache-Control', 'public, max-age=86400'); // Cache for 24 hours
        res.setHeader('content-type', response.headers.get('content-type') || 'image/jpeg');
        
        // Pipe the response
        const arrayBuffer = await response.arrayBuffer();
        res.send(Buffer.from(arrayBuffer));
      } catch (error) {
        console.error("Error fetching place photo:", error);
        res.status(502).json({ message: "Error fetching photo from Google Maps" });
      }
    } catch (error) {
      console.error("Place photo proxy error:", error);
      res.status(500).json({ message: "Failed to proxy place photo" });
    }
  });

  // Google Maps Static Map Proxy
  // This avoids exposing the API key in client-side code
  // Google Maps JavaScript API Proxy Endpoint to avoid exposing API key on frontend
  app.get("/api/maps/js", async (req, res) => {
    try {
      // Get the Google Maps API key from environment variable
      const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;
      
      if (!GOOGLE_MAPS_API_KEY) {
        return res.status(500).json({ error: "Missing Google Maps API key" });
      }
      
      // Get optional libraries parameter
      const libraries = req.query.libraries || "places";
      
      // Build the Google Maps JavaScript API URL
      const mapsUrl = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=${libraries}`;
      
      // Fetch the Google Maps JavaScript API
      const response = await fetch(mapsUrl);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch Google Maps JavaScript API: ${response.statusText}`);
      }
      
      // Get the JavaScript content
      const jsContent = await response.text();
      
      // Set the appropriate content type header
      res.set('Content-Type', 'application/javascript');
      
      // Send the JavaScript
      res.send(jsContent);
    } catch (error) {
      console.error("Error fetching Google Maps JavaScript API:", error);
      res.status(500).json({ error: "Failed to fetch Google Maps JavaScript API" });
    }
  });
  
  // Static map endpoint has been removed as we now use interactive maps

  // Place details API endpoint to get detailed information about a specific place
  app.get("/api/place/details", async (req, res) => {
    try {
      const placeId = req.query.placeId;
      
      if (!placeId || typeof placeId !== 'string') {
        return res.status(400).json({ message: "Place ID is required" });
      }
      
      if (!GOOGLE_MAPS_API_KEY) {
        console.error("Missing Google Maps API key for place details");
        return res.status(503).json({ message: "Maps service unavailable" });
      }
      
      console.log(`Fetching details for place: ${placeId}`);
      
      // Create cache key for this place
      const cacheKey = `place_details:${placeId}`;
      
      // Check if we have this place cached
      const cachedPlace = await cacheService.get(cacheKey);
      if (cachedPlace) {
        console.log(`Using cached details for place: ${placeId}`);
        return res.json(cachedPlace);
      }
      
      // Use the Google Maps Places API to get place details
      const url = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&fields=name,formatted_address,geometry,photo,rating,user_ratings_total,type,opening_hours&key=${GOOGLE_MAPS_API_KEY}`;
      
      const response = await fetch(url);
      
      if (!response.ok) {
        console.error(`Google Maps API error: ${response.status}`);
        return res.status(502).json({ message: "Error fetching place details from Google Maps" });
      }
      
      const data = await response.json();
      
      if (data.status !== "OK" || !data.result) {
        console.error("Failed to get place details:", data.status, data.error_message);
        return res.status(404).json({ message: "Place not found" });
      }
      
      // Extract relevant place details
      const placeDetails = {
        placeId: placeId,
        name: data.result.name,
        formattedAddress: data.result.formatted_address,
        location: data.result.geometry?.location,
        photos: data.result.photos,
        photoReferences: data.result.photos?.map((photo: any) => photo.photo_reference) || [],
        rating: data.result.rating,
        userRatingsTotal: data.result.user_ratings_total,
        types: data.result.types,
        openNow: data.result.opening_hours?.open_now
      };
      
      // Cache the place details for 24 hours
      await cacheService.set(cacheKey, placeDetails, 86400);
      
      res.json(placeDetails);
    } catch (error) {
      console.error("Error fetching place details:", error);
      res.status(500).json({ message: "Failed to fetch place details" });
    }
  });

  app.get("/api/place/search", async (req, res) => {
    try {
      const query = req.query.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      if (!GOOGLE_MAPS_API_KEY) {
        console.error("Missing Google Maps API key for place search");
        return res.status(503).json({ message: "Maps service unavailable" });
      }
      
      // Check in-memory cache for this query
      const cacheKey = `place_search:${query.toLowerCase().trim()}`;
      const cachedResults = await cacheService.get(cacheKey);
      
      if (cachedResults) {
        console.log(`Using cached place search results for: "${query}"`);
        return res.json(cachedResults);
      }
      
      console.log(`Searching for places matching: "${query}"`);
      
      // Use the Google Maps Places API to search for places
      const url = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(query)}&key=${GOOGLE_MAPS_API_KEY}`;
      
      const response = await fetch(url);
      
      if (!response.ok) {
        console.error(`Google Maps place search API error: ${response.status}`);
        throw new Error(`Google Maps API error: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Extract relevant place information
      const places = data.results.map((place: any) => ({
        placeId: place.place_id,
        name: place.name,
        address: place.formatted_address,
        location: place.geometry?.location,
        photos: place.photos,
        photoReference: place.photos?.[0]?.photo_reference || null,
        types: place.types
      }));
      
      res.json(places);
    } catch (error) {
      console.error('Error searching for places:', error);
      res.status(500).json({ message: 'Failed to search for places' });
    }
  });

  // Add validation schema for itinerary generation
  const itineraryRequestSchema = z.object({
    destination: z.string().min(2),
    startDate: z.string(),
    endDate: z.string(),
    travelers: z.number().int().positive(),
    adventureLevel: z.enum(["low", "medium", "high"]),
    budgetRange: z.enum(["budget", "mid-range", "luxury"]),
    paceLevel: z.enum(["relaxed", "moderate", "intense"]),
    selectedActivities: z.array(z.string()),
    photoReference: z.string().nullable().optional()
  });

  // Generate an AI-powered travel itinerary
  app.post("/api/itinerary/generate", async (req, res) => {
    try {
      console.log("Received itinerary generation request:", req.body);
      
      // Validate request body against schema
      const itineraryParams = itineraryRequestSchema.parse(req.body);
      
      // Check for GEMINI_API_KEY
      if (!process.env.GEMINI_API_KEY) {
        console.error("Missing Gemini API key for itinerary generation");
        return res.status(503).json({ message: "Itinerary service unavailable" });
      }
      
      // Call the itinerary service to generate the itinerary
      console.log("Generating itinerary with params:", itineraryParams);
      const itinerary = await itineraryService.generateItinerary(itineraryParams);
      
      console.log("Itinerary generated successfully");
      res.json(itinerary);
    } catch (error) {
      console.error("Error generating itinerary:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid itinerary request data", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ message: "Failed to generate itinerary" });
    }
  });
  
  // Schema for activity editing
  const activityEditSchema = z.object({
    dayNumber: z.number().int().positive(),
    activityIndex: z.number().int().min(0).optional(),
    activity: z.object({
      time: z.string(),
      name: z.string().min(1),
      description: z.string(),
      location: z.string().optional(),
      price: z.string().optional(),
      category: z.string().optional(),
      isFree: z.boolean().optional(),
      placeId: z.string().optional(),
    }).optional()
  });
  
  // Update an existing itinerary by adding, removing, or replacing activities
  app.post("/api/itinerary/edit", async (req, res) => {
    try {
      console.log("Received itinerary edit request:", req.body);
      
      if (!req.body.itinerary) {
        return res.status(400).json({ message: "Itinerary is required" });
      }
      
      // Get the operation type
      const operation = req.body.operation;
      if (!['add', 'remove', 'replace'].includes(operation)) {
        return res.status(400).json({ message: "Valid operation required (add, remove, or replace)" });
      }
      
      // Validate edit parameters
      const validatedParams = activityEditSchema.parse(req.body);
      const { dayNumber, activityIndex, activity } = validatedParams;
      
      // Make a copy of the itinerary to modify
      const itinerary = {...req.body.itinerary};
      
      // Find the day to modify
      const dayToModify = itinerary.days.find((day: ItineraryDay) => day.dayNumber === dayNumber);
      if (!dayToModify) {
        return res.status(404).json({ message: `Day ${dayNumber} not found in itinerary` });
      }
      
      // Perform the requested operation
      switch (operation) {
        case 'add':
          if (!activity) {
            return res.status(400).json({ message: "Activity is required for add operation" });
          }
          // Add new activity
          console.log(`Adding new activity to day ${dayNumber}`);
          dayToModify.activities.push(activity);
          break;
          
        case 'remove':
          if (activityIndex === undefined) {
            return res.status(400).json({ message: "Activity index is required for remove operation" });
          }
          // Check if activityIndex is valid
          if (activityIndex < 0 || activityIndex >= dayToModify.activities.length) {
            return res.status(400).json({ message: `Invalid activity index: ${activityIndex}` });
          }
          // Remove activity
          console.log(`Removing activity at index ${activityIndex} from day ${dayNumber}`);
          dayToModify.activities.splice(activityIndex, 1);
          break;
          
        case 'replace':
          if (activityIndex === undefined || !activity) {
            return res.status(400).json({ 
              message: "Both activity index and new activity are required for replace operation" 
            });
          }
          // Check if activityIndex is valid
          if (activityIndex < 0 || activityIndex >= dayToModify.activities.length) {
            return res.status(400).json({ message: `Invalid activity index: ${activityIndex}` });
          }
          // Replace activity
          console.log(`Replacing activity at index ${activityIndex} on day ${dayNumber}`);
          dayToModify.activities[activityIndex] = activity;
          break;
      }
      
      // If a new or replaced activity has a placeId, enhance it with Google Maps data
      if ((operation === 'add' || operation === 'replace') && activity?.placeId) {
        try {
          console.log(`Enhancing new activity with place data for placeId: ${activity.placeId}`);
          // Fetch place details
          const destination = itinerary.destination;
          await itineraryService.enhanceActivityWithPlaceData(activity, destination);
        } catch (enhanceError) {
          console.error("Error enhancing activity with place data:", enhanceError);
          // Continue without failing the whole request
        }
      } else if ((operation === 'add' || operation === 'replace') && activity?.name) {
        // Try to find matching place data if placeId is not provided
        try {
          console.log(`Searching for place data for activity: ${activity.name}`);
          const destination = itinerary.destination;
          await itineraryService.enhanceActivityWithPlaceData(activity, destination);
        } catch (enhanceError) {
          console.error("Error finding place data for activity:", enhanceError);
          // Continue without failing the whole request
        }
      }
      
      // Sort activities by time (if times are provided)
      dayToModify.activities.sort((a: { time?: string }, b: { time?: string }) => {
        // Convert time strings to comparable values
        const timeA = a.time ? a.time.replace(':', '') : '0000';
        const timeB = b.time ? b.time.replace(':', '') : '0000';
        return timeA.localeCompare(timeB);
      });
      
      // Return the updated itinerary
      res.json(itinerary);
    } catch (error) {
      console.error("Error editing itinerary:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid edit request data", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ message: "Failed to edit itinerary" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
