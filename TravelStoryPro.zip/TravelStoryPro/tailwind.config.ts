import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./client/index.html", "./client/src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        'sans': ['Montserrat', 'sans-serif'],
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
        'card': 'var(--radius-card)',
        'button': 'var(--radius-button)',
      },
      colors: {
        ventu: {
          teal: '#1DCDBC',
          navy: '#102B40',
          coral: '#FF6B5B',
          white: '#FFFFFF',
          sand: '#F7F3EB',
          gray: '#6A7B89',
          midnight: '#0A1A2A',
          sunbeam: '#FFD166',
        },
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        primary: {
          DEFAULT: "#1DCDBC", // Ventu Teal
          foreground: "#FFFFFF", // White
          light: "rgba(29, 205, 188, 0.15)", // Ventu Teal with opacity
        },
        secondary: {
          DEFAULT: "#102B40", // Deep Navy
          foreground: "#FFFFFF", // White
        },
        muted: {
          DEFAULT: "#6A7B89", // Slate Gray
          foreground: "#FFFFFF",
        },
        accent: {
          DEFAULT: "#FF6B5B", // Warm Coral
          foreground: "#FFFFFF", // White
        },
        destructive: {
          DEFAULT: "#FF6B5B", // Warm Coral
          foreground: "#FFFFFF", // White
        },
        border: "#E1DDD6", // Lighter version of Soft Sand
        input: "#F7F3EB", // Soft Sand
        ring: "#1DCDBC", // Ventu Teal
        chart: {
          "1": "#1DCDBC", // Ventu Teal
          "2": "#102B40", // Deep Navy
          "3": "#FF6B5B", // Warm Coral
          "4": "#FFD166", // Sunbeam
          "5": "#6A7B89", // Slate Gray
        },
        sidebar: {
          DEFAULT: "#102B40", // Deep Navy 
          foreground: "#FFFFFF", // White
          primary: "#1DCDBC", // Ventu Teal
          "primary-foreground": "#FFFFFF", // White
          accent: "#FF6B5B", // Warm Coral
          "accent-foreground": "#FFFFFF", // White
          border: "#1D3A50", // Lighter version of Deep Navy
          ring: "#1DCDBC", // Ventu Teal
        },
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate"), require("@tailwindcss/typography")],
} satisfies Config;
