import { createContext, useContext, useEffect, useState } from 'react';
import { 
  User, 
  signOut, 
  onAuthStateChanged,
  GoogleAuthProvider,
  FacebookAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  AuthCredential
} from 'firebase/auth';
import { auth } from '@/config/firebase';

interface AuthContextType {
  currentUser: User | null;
  signInWithGoogle: () => Promise<void>;
  signInWithFacebook: () => Promise<void>;
  logout: () => Promise<void>;
  loading: boolean;
  setLocation: (path: string) => void; // Added setLocation function
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Sign in with Google
  const signInWithGoogle = async (): Promise<void> => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Error signing in with Google:", error);
      throw error;
    }
  }

  // Sign in with Facebook
  const signInWithFacebook = async (): Promise<void> => {
    try {
      const provider = new FacebookAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const credential = FacebookAuthProvider.credentialFromResult(result);
      const token = credential?.accessToken;
      console.log("Facebook auth successful, token available:", !!token);
      setLocation('/'); // Redirect to homepage after successful login
    } catch (error) {
      console.error("Error signing in with Facebook:", error);
      throw error;
    }
  }

  // Sign out
  const logout = async (): Promise<void> => {
    try {
      await signOut(auth);
      // Redirect to home page after logout
      window.location.href = '/';
    } catch (error) {
      console.error("Error signing out:", error);
      throw error;
    }
  };

    // Placeholder for navigation - Replace with your actual routing solution
  const setLocation = (path: string) => {
    // Example using window.location -  Replace with your preferred routing method (e.g., React Router's useNavigate)
    window.location.href = path;
  };


  // Listen to auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setLoading(false);
    });

    // Cleanup subscription on unmount
    return unsubscribe;
  }, []);

  const value = {
    currentUser,
    signInWithGoogle,
    signInWithFacebook,
    logout,
    loading,
    setLocation // Include setLocation in the context value
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};