import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Process Google Maps photo URLs to use our secure proxy
 * Replaces direct Google Maps photo URLs with our server proxy endpoint
 * This prevents exposing API keys in client-side code
 */
export function processPhotoUrl(photoUrl: string | undefined): string {
  if (!photoUrl) return "https://placehold.co/600x400?text=No+Image";
  
  // Check if this is a Google Maps photo URL
  if (photoUrl.includes('maps.googleapis.com/maps/api/place/photo')) {
    try {
      // Extract the photo reference from the URL
      const url = new URL(photoUrl);
      const photoReference = url.searchParams.get('photoreference');
      const maxWidth = url.searchParams.get('maxwidth') || '400';
      
      if (photoReference) {
        // Use our proxy endpoint instead
        return `/api/place/photo?reference=${photoReference}&maxwidth=${maxWidth}`;
      }
    } catch (e) {
      console.error('Failed to parse photo URL:', e);
    }
  }
  
  // Return the original URL if it's not a Google Maps photo or if extraction failed
  return photoUrl;
}
