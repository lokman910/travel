/**
 * Main application entry point and routing configuration
 * This file sets up the core application structure including routing and global providers
 */

import { Switch, Route, useLocation } from "wouter";  // Lightweight routing solution
import { QueryClientProvider } from "@tanstack/react-query";  // Data fetching and caching
import { queryClient } from "./lib/queryClient";  // Custom query client configuration
import { Toaster } from "@/components/ui/toaster";  // Toast notification system
import NotFound from "@/pages/not-found";  // 404 page component
import HomePage from "@/pages/HomePage";  // Landing/home page
import PlanningPage from "@/pages/PlanningPage";  // Trip planning interface
import ProfilePage from "@/pages/ProfilePage";  // User profile management
import LoginPage from "@/pages/LoginPage";  // Authentication page
import BottomNavigation from "@/components/BottomNavigation";  // Mobile navigation bar
import { AuthProvider } from './contexts/AuthContext'; // Added AuthProvider import
import { Button } from "@/components/ui/button";
import { LogIn } from "lucide-react";
import { useAuth } from "./contexts/AuthContext";

/**
 * Router Component
 * Handles the application's routing logic and main layout structure
 * Implements a mobile-first design with bottom navigation
 * @returns {JSX.Element} The router component with routes and navigation
 */

function Router() {
  const [, setLocation] = useLocation();
  const { currentUser } = useAuth();
  
  return (
    // Container with full height and gradient background
    <div className="min-h-screen bg-cloud pb-16 relative">
      {/* Fixed login button for non-authenticated users - only shown on homepage */}
      {!currentUser && location === "/" && (
        <div className="fixed top-0 right-0 z-50 m-4">
          <Button 
            size="sm"
            variant="default"
            className="shadow-md flex items-center gap-1 font-medium"
            onClick={() => setLocation("/login")}
          >
            <LogIn className="h-4 w-4 mr-1" />
            Login
          </Button>
        </div>
      )}
    
      {/* Route Switch: Renders the first matching route
          Current routes:
          - / -> Home page
          - /plan -> Trip planning interface
          - /profile -> User profile
          - /login -> Authentication page
          - * -> 404 Not Found */}
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/plan" component={PlanningPage} />
        <Route path="/profile" component={ProfilePage} />
        <Route path="/login" component={LoginPage} />
        <Route component={NotFound} />
      </Switch>

      {/* Persistent bottom navigation bar for mobile-first navigation
          Fixed to bottom of screen with 16px padding (pb-16) above */}
      <BottomNavigation />
    </div>
  );
}

/**
 * App Component
 * Root component that wraps the entire application
 * Provides global functionality through providers:
 * - QueryClientProvider: Manages API data fetching and caching
 * - Toaster: Handles toast notifications across the app
 * @returns {JSX.Element} The complete application with all providers
 */
function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;