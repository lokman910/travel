import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Pencil, Trash2, MapPin, Clock, Tag, X, Check } from 'lucide-react';
import { motion } from 'framer-motion';
import { processPhotoUrl } from '@/lib/utils';
import { addActivityToItinerary, removeActivityFromItinerary, replaceActivityInItinerary, ItineraryActivity } from '@/services/LocationService';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

interface LocationCardProps {
  activity: ItineraryActivity;
  dayNumber?: number;
  activityIndex?: number;
  itinerary?: any;
  onUpdateItinerary?: (updatedItinerary: any) => void;
}

export const LocationCard: React.FC<LocationCardProps> = ({ 
  activity,
  dayNumber,
  activityIndex,
  itinerary,
  onUpdateItinerary
}) => {
  // State
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [editedActivity, setEditedActivity] = useState<ItineraryActivity>({...activity});
  const [editedDayNumber, setEditedDayNumber] = useState<number | null>(dayNumber || null);

  // Category configuration - determine icon and color based on category
  const getCategoryConfig = (category: string) => {
    switch (category?.toLowerCase()) {
      case 'cultural':
        return { color: 'bg-blue-500', icon: <Tag className="h-4 w-4" /> };
      case 'culinary':
        return { color: 'bg-red-500', icon: <Tag className="h-4 w-4" /> };
      case 'entertainment':
        return { color: 'bg-yellow-500', icon: <Tag className="h-4 w-4" /> };
      case 'outdoor':
        return { color: 'bg-green-500', icon: <Tag className="h-4 w-4" /> };
      case 'shopping':
        return { color: 'bg-purple-500', icon: <Tag className="h-4 w-4" /> };
      case 'adventure':
        return { color: 'bg-indigo-500', icon: <Tag className="h-4 w-4" /> };
      case 'relaxation':
        return { color: 'bg-teal-500', icon: <Tag className="h-4 w-4" /> };
      default:
        return { color: 'bg-gray-500', icon: <Tag className="h-4 w-4" /> };
    }
  };
  
  // Function to handle field changes in edit mode
  const handleFieldChange = (field: keyof ItineraryActivity, value: string) => {
    setEditedActivity({
      ...editedActivity,
      [field]: value
    });
  };

  // Function to handle save of edited activity
  const handleSaveEdit = async () => {
    if (!itinerary || dayNumber === undefined || activityIndex === undefined || !onUpdateItinerary) {
      console.error('Cannot save edit: missing required props');
      return;
    }
    
    try {
      let updatedItinerary = itinerary;
      
      // Check if the activity is being moved to a different day
      if (editedDayNumber !== null && editedDayNumber !== dayNumber) {
        // First remove the activity from the current day
        updatedItinerary = await removeActivityFromItinerary(
          itinerary,
          dayNumber,
          activityIndex
        );
        
        // Then add it to the new day
        updatedItinerary = await addActivityToItinerary(
          updatedItinerary,
          editedDayNumber,
          editedActivity
        );
      } else {
        // If not moving to a different day, just update the activity
        updatedItinerary = await replaceActivityInItinerary(
          itinerary,
          dayNumber,
          activityIndex,
          editedActivity
        );
      }
      
      // Update the parent component with the new itinerary
      onUpdateItinerary(updatedItinerary);
      
      // Exit edit mode
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating activity:', error);
    }
  };

  // Function to handle activity deletion
  const handleDelete = async () => {
    if (!itinerary || dayNumber === undefined || activityIndex === undefined || !onUpdateItinerary) {
      console.error('Cannot delete: missing required props');
      return;
    }
    
    try {
      // Remove the activity from the itinerary
      const updatedItinerary = await removeActivityFromItinerary(
        itinerary,
        dayNumber,
        activityIndex
      );
      
      // Update the parent component with the new itinerary
      onUpdateItinerary(updatedItinerary);
    } catch (error) {
      console.error('Error deleting activity:', error);
    }
  };

  // Get color and icon for the category
  const { color, icon } = getCategoryConfig(activity.category || '');
  
  // Determine if location has photo
  const hasPhoto = activity.photoReference || activity.photoReferences?.[0];
  const photoUrl = hasPhoto 
    ? processPhotoUrl(`/api/place/photo?reference=${activity.photoReference || activity.photoReferences?.[0]}&maxwidth=800`) 
    : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      layout
    >
      <Card className="overflow-hidden h-full flex flex-col">
        <div className="flex flex-col h-full">
          {/* Photo area (if available) */}
          {photoUrl && (
            <div className="relative h-32 overflow-hidden">
              <img
                src={photoUrl}
                alt={activity.name}
                className="w-full h-full object-cover"
              />
              {/* Category badge */}
              {activity.category && (
                <div className={`absolute top-2 left-2 ${color} text-white text-xs px-2 py-1 rounded-full flex items-center`}>
                  {icon}
                  <span className="ml-1">{activity.category}</span>
                </div>
              )}
            </div>
          )}

          {/* Content area */}
          <div className="p-4 flex-1 flex flex-col">
            {/* Display mode */}
            {!isEditing ? (
              <>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-medium text-sm">{activity.name}</h3>
                    {activity.time && (
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <Clock className="h-3 w-3 mr-1" />
                        {activity.time}
                      </div>
                    )}
                  </div>
                  
                  {/* Edit and delete buttons (only if editing is enabled) */}
                  {dayNumber !== undefined && activityIndex !== undefined && itinerary && onUpdateItinerary && (
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 w-7 p-0"
                        onClick={() => setIsEditing(true)}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0 text-red-500 hover:text-red-600"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Activity</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to remove "{activity.name}" from your itinerary?
                              This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDelete}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  )}
                </div>
                
                {/* Description */}
                {activity.description && (
                  <p className="text-xs text-gray-600 mt-1 mb-2 line-clamp-3">
                    {activity.description}
                  </p>
                )}
                
                {/* Location */}
                {activity.location && (
                  <div className="flex items-center text-xs text-gray-500 mt-auto">
                    <MapPin className="h-3 w-3 mr-1 flex-shrink-0" />
                    <span className="truncate">{activity.location}</span>
                  </div>
                )}
              </>
            ) : (
              // Edit mode
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Time</label>
                  <input
                    type="text"
                    value={editedActivity.time || ''}
                    onChange={(e) => handleFieldChange('time', e.target.value)}
                    className="w-full px-2 py-1 text-sm border rounded-md"
                    placeholder="e.g. 9:00 AM, Morning, Afternoon"
                  />
                  <p className="text-xs text-gray-500 mt-1">You can edit the time for this activity</p>
                </div>
                
                {itinerary && dayNumber && (
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">Day</label>
                    <select
                      value={editedDayNumber || dayNumber}
                      onChange={(e) => setEditedDayNumber(parseInt(e.target.value))}
                      className="w-full px-2 py-1 text-sm border rounded-md"
                    >
                      {itinerary.days.map((day: any) => (
                        <option key={day.dayNumber} value={day.dayNumber}>
                          Day {day.dayNumber}: {day.date}
                        </option>
                      ))}
                    </select>
                    <p className="text-xs text-gray-500 mt-1">You can move this activity to a different day</p>
                  </div>
                )}
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Name</label>
                  <div className="px-3 py-2 text-sm bg-gray-50 border rounded-md">
                    {editedActivity.name}
                  </div>
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Description</label>
                  <div className="px-3 py-2 text-sm bg-gray-50 border rounded-md min-h-[60px] whitespace-pre-wrap">
                    {editedActivity.description || 'No description available'}
                  </div>
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Location</label>
                  <div className="px-3 py-2 text-sm bg-gray-50 border rounded-md">
                    {editedActivity.location || 'No location specified'}
                  </div>
                </div>
                <div className="flex justify-end gap-2 mt-3">
                  <Button
                    variant="default"
                    size="sm"
                    className="h-8 px-3 text-xs"
                    onClick={handleSaveEdit}
                  >
                    <Check className="h-3.5 w-3.5 mr-1" /> Save
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 px-3 text-xs"
                    onClick={() => {
                      setEditedActivity({...activity}); // Reset changes
                      setIsEditing(false);
                    }}
                  >
                    <X className="h-3.5 w-3.5 mr-1" /> Cancel
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default LocationCard;