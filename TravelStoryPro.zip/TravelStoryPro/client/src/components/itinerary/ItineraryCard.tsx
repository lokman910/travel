import { formatDistanceToNow } from "date-fns";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Pencil, Eye, Share2, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { processPhotoUrl } from "@/lib/utils";

interface ItineraryCardProps {
  id: string | number;
  destination: string;
  startDate: string;
  endDate: string;
  coverImage?: string;
  photoReference?: string;
  activities?: any[];
  preferences?: {
    adventureLevel?: string;
    budgetRange?: string;
    selectedActivities?: string[];
  };
  onView: () => void;
  onEdit: () => void;
  onShare: () => void;
}

const ItineraryCard = ({
  id,
  destination,
  startDate,
  endDate,
  coverImage,
  photoReference,
  activities,
  preferences,
  onView,
  onEdit,
  onShare
}: ItineraryCardProps) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  
  // Calculate trip duration
  const start = new Date(startDate);
  const end = new Date(endDate);
  const tripDuration = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  
  // Format dates for display
  const formattedStartDate = start.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  });
  
  const formattedEndDate = end.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric"
  });

  // Get the destination image
  useEffect(() => {
    const fetchImage = async () => {
      if (coverImage) {
        setImageUrl(coverImage);
        return;
      }
      
      if (photoReference) {
        setImageUrl(`/api/place/photo?reference=${photoReference}&maxwidth=800`);
        return;
      }

      if (destination) {
        try {
          setLoading(true);
          // If we don't have a photo reference or cover image, try to get one for the destination
          const response = await fetch(`/api/place/search?query=${encodeURIComponent(destination)}`);
          if (response.ok) {
            const data = await response.json();
            if (data && data.length > 0 && data[0].photoReference) {
              setImageUrl(`/api/place/photo?reference=${data[0].photoReference}&maxwidth=800`);
            } else {
              // Fallback to Unsplash if we can't find a Google Maps photo
              setImageUrl(`https://source.unsplash.com/800x400/?${encodeURIComponent(destination + ' travel')}`);
            }
          }
        } catch (error) {
          console.error("Error fetching destination image:", error);
          // Fallback to Unsplash
          setImageUrl(`https://source.unsplash.com/800x400/?${encodeURIComponent(destination + ' travel')}`);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchImage();
  }, [destination, photoReference, coverImage]);

  return (
    <Card 
      className="overflow-hidden flex flex-col h-full shadow-md transition-all duration-300 hover:shadow-lg hover:translate-y-[-2px] cursor-pointer group"
      onClick={onView}
    >
      <div className="h-40 bg-gray-200 relative">
        {loading ? (
          <div className="w-full h-full flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
          </div>
        ) : imageUrl ? (
          <img
            src={imageUrl}
            alt={destination}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400">
            No image available
          </div>
        )}
        
        {/* View overlay that appears on hover */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
          <Button size="sm" variant="secondary" className="shadow-lg">
            <Eye className="w-4 h-4 mr-1" />
            View Itinerary
          </Button>
        </div>
      </div>
      
      <div className="p-4 flex-grow">
        <h3 className="font-bold text-lg group-hover:text-primary">{destination}</h3>
        <p className="text-sm text-gray-500 mb-2">
          {formattedStartDate} - {formattedEndDate} ({tripDuration} days)
        </p>
        
        {preferences?.selectedActivities && preferences.selectedActivities.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {preferences.selectedActivities.slice(0, 3).map((activity, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {activity}
              </Badge>
            ))}
            {preferences.selectedActivities.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{preferences.selectedActivities.length - 3} more
              </Badge>
            )}
          </div>
        )}

        {preferences?.budgetRange && (
          <div className="mb-3">
            <Badge variant="secondary" className="capitalize">
              {preferences.budgetRange}
            </Badge>
          </div>
        )}
      </div>
      
      <div className="p-3 bg-gray-50 border-t flex justify-between" onClick={(e) => e.stopPropagation()}>
        <Button size="sm" variant="ghost" onClick={(e) => {
          e.stopPropagation();
          onView();
        }}>
          <Eye className="w-4 h-4 mr-1" />
          View
        </Button>
        <Button size="sm" variant="ghost" onClick={(e) => {
          e.stopPropagation();
          onEdit();
        }}>
          <Pencil className="w-4 h-4 mr-1" />
          Edit
        </Button>
        <Button size="sm" variant="ghost" onClick={(e) => {
          e.stopPropagation();
          onShare();
        }}>
          <Share2 className="w-4 h-4 mr-1" />
          Share
        </Button>
      </div>
    </Card>
  );
};

export default ItineraryCard;