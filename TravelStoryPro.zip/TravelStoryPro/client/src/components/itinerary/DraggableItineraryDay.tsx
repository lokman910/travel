import React from 'react';
import { DragDropContext, Droppable, Draggable, DropResult } from 'react-beautiful-dnd';
import { Card } from '@/components/ui/card';
import { ItineraryDay, ItineraryActivity } from '@/services/LocationService';
import LocationCard from '@/components/itinerary/LocationCard';
import { CalendarDays } from 'lucide-react';

interface DraggableItineraryDayProps {
  day: ItineraryDay;
  dayNumber: number;
  itinerary: any;
  onUpdateItinerary: (updatedItinerary: any) => void;
}

export const DraggableItineraryDay: React.FC<DraggableItineraryDayProps> = ({
  day,
  dayNumber,
  itinerary,
  onUpdateItinerary
}) => {
  // Handle drag end event
  const handleDragEnd = (result: DropResult) => {
    const { source, destination } = result;

    // dropped outside the list
    if (!destination) {
      return;
    }

    // If the position didn't change
    if (
      source.droppableId === destination.droppableId &&
      source.index === destination.index
    ) {
      return;
    }

    // Create a deep copy of the itinerary to work with
    const updatedItinerary = JSON.parse(JSON.stringify(itinerary));
    
    // Find the day we're working with
    const currentDay = updatedItinerary.days.find((d: ItineraryDay) => d.dayNumber === dayNumber);
    
    if (!currentDay) {
      console.error('Day not found in itinerary');
      return;
    }

    // Get the activity that was moved
    const [movedActivity] = currentDay.activities.splice(source.index, 1);
    
    // Insert the activity at its new position
    currentDay.activities.splice(destination.index, 0, movedActivity);
    
    // Update time of day for the activity based on its new position
    // This is optional but helps create a more natural time flow
    redistributeActivityTimes(currentDay.activities);
    
    // Update the itinerary with the changes
    onUpdateItinerary(updatedItinerary);
  };

  // Helper function to redistribute activity times based on position
  const redistributeActivityTimes = (activities: ItineraryActivity[]) => {
    // This is a simple approach - for a more sophisticated implementation,
    // you might want to use actual time intervals or categorize by morning/afternoon/evening
    activities.forEach((activity, index) => {
      const position = index / (activities.length - 1 || 1); // Normalized position (0 to 1)
      
      // Map position to a time of day
      if (position < 0.25) {
        activity.time = activity.time?.includes('AM') ? activity.time : 'Morning';
      } else if (position < 0.5) {
        activity.time = activity.time?.includes('PM') && parseInt(activity.time) < 4 
          ? activity.time 
          : 'Late Morning';
      } else if (position < 0.75) {
        activity.time = activity.time?.includes('PM') && parseInt(activity.time) >= 4 
          ? activity.time 
          : 'Afternoon';
      } else {
        activity.time = activity.time?.includes('PM') && parseInt(activity.time) >= 6 
          ? activity.time 
          : 'Evening';
      }
    });
  };

  return (
    <Card className="p-4 mb-6">
      <div className="flex items-center mb-4">
        <CalendarDays className="h-5 w-5 mr-2 text-primary" />
        <h3 className="font-medium text-lg">
          Day {day.dayNumber}: {day.date}
        </h3>
      </div>
      
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId={`day-${dayNumber}`}>
          {(provided) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className="space-y-4"
            >
              {day.activities.map((activity, index) => (
                <Draggable 
                  key={`${activity.name}-${index}`} 
                  draggableId={`activity-${dayNumber}-${index}`} 
                  index={index}
                >
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      style={{
                        ...provided.draggableProps.style,
                        opacity: snapshot.isDragging ? 0.8 : 1
                      }}
                    >
                      <LocationCard
                        activity={activity}
                        dayNumber={dayNumber}
                        activityIndex={index}
                        itinerary={itinerary}
                        onUpdateItinerary={onUpdateItinerary}
                      />
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </Card>
  );
};

export default DraggableItineraryDay;