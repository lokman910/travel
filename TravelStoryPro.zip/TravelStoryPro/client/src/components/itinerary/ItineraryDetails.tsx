import React, { useState } from 'react';
import { format, parseISO } from 'date-fns';
import { DraggableItineraryDetails } from '@/components/itinerary/DraggableItineraryDetails';
import { motion } from "framer-motion";
import { 
  Ticket, Utensils, SunSnow, ShoppingBag, Dumbbell, Coffee, 
  Tag, Sunrise, Sun, Sunset, Moon
} from 'lucide-react';

// Time period indicators for the timeline
const TimePeriodIndicator = ({ period }: { period: 'morning' | 'afternoon' | 'evening' | 'night' }) => {
  const icons = {
    morning: <Sunrise className="h-4 w-4 text-orange-500" />,
    afternoon: <Sun className="h-4 w-4 text-yellow-500" />,
    evening: <Sunset className="h-4 w-4 text-indigo-500" />,
    night: <Moon className="h-4 w-4 text-blue-900" />
  };
  
  const labels = {
    morning: 'Morning',
    afternoon: 'Afternoon',
    evening: 'Evening',
    night: 'Night'
  };
  
  const bgColors = {
    morning: 'bg-orange-50',
    afternoon: 'bg-yellow-50',
    evening: 'bg-indigo-50',
    night: 'bg-blue-50'
  };
  
  const textColors = {
    morning: 'text-orange-800',
    afternoon: 'text-yellow-800',
    evening: 'text-indigo-800',
    night: 'text-blue-800'
  };
  
  const borderColors = {
    morning: 'border-l-orange-400',
    afternoon: 'border-l-yellow-400',
    evening: 'border-l-indigo-400',
    night: 'border-l-blue-400'
  };
  
  // Animation variants
  const indicatorVariants = {
    initial: { opacity: 0, x: -20 },
    animate: { opacity: 1, x: 0, transition: { duration: 0.3 } }
  };
  
  return (
    <motion.div 
      initial="initial"
      animate="animate"
      variants={indicatorVariants}
      className={`flex items-center gap-2 p-2 pl-3 rounded-md my-3 ${bgColors[period]} ${textColors[period]} border-l-4 ${borderColors[period]}`}
    >
      <div>{icons[period]}</div>
      <div className="text-sm font-medium">{labels[period]}</div>
    </motion.div>
  );
};

interface ItineraryDetailsProps {
  itinerary: any;
  onClose: () => void;
  onDelete?: (id: string | number) => void;
}

// Category icon mapping
const categoryIcons: Record<string, React.ReactNode> = {
  cultural: <Ticket className="h-4 w-4" />,
  culinary: <Utensils className="h-4 w-4" />,
  entertainment: <Ticket className="h-4 w-4" />,
  outdoor: <SunSnow className="h-4 w-4" />,
  shopping: <ShoppingBag className="h-4 w-4" />,
  adventure: <Dumbbell className="h-4 w-4" />,
  relaxation: <Coffee className="h-4 w-4" />,
};

// The main component now uses the draggable version
const ItineraryDetails: React.FC<ItineraryDetailsProps> = ({ itinerary: initialItinerary, onClose, onDelete }) => {
  const [itinerary, setItinerary] = useState(initialItinerary);

  if (!itinerary) return null;

  const handleDelete = () => {
    if (onDelete && itinerary.id) {
      onDelete(itinerary.id);
      onClose();
    }
  };

  // Use the draggable version
  return (
    <DraggableItineraryDetails
      itinerary={itinerary}
      onClose={onClose}
      onDelete={onDelete}
      onUpdateItinerary={setItinerary}
    />
  );
};

export default ItineraryDetails;