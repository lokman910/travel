import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable, DropResult } from 'react-beautiful-dnd';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sheet, SheetClose, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { X, FileEdit, Share, Trash2, ArrowLeft } from 'lucide-react';
import { Itinerary, ItineraryDay, ItineraryActivity } from '@/services/LocationService';
import LocationCard from '@/components/itinerary/LocationCard';
import DraggableItineraryDay from '@/components/itinerary/DraggableItineraryDay';

interface DraggableItineraryDetailsProps {
  itinerary: Itinerary;
  onClose: () => void;
  onDelete?: (id: string | number) => void;
  onUpdateItinerary: (updatedItinerary: Itinerary) => void;
}

export const DraggableItineraryDetails: React.FC<DraggableItineraryDetailsProps> = ({
  itinerary,
  onClose,
  onDelete,
  onUpdateItinerary
}) => {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  // Handle drag end between days
  const handleDragEnd = (result: DropResult) => {
    const { source, destination } = result;

    // Dropped outside a droppable area
    if (!destination) {
      return;
    }

    // Source and destination are the same - not moving between days
    if (source.droppableId === destination.droppableId) {
      return;
    }

    // Extract the day numbers from the droppable IDs
    const sourceDayNumber = parseInt(source.droppableId.split('-')[1]);
    const destDayNumber = parseInt(destination.droppableId.split('-')[1]);

    // Create a deep copy of the itinerary to work with
    const updatedItinerary = JSON.parse(JSON.stringify(itinerary));
    
    // Find the source and destination days
    const sourceDay = updatedItinerary.days.find((d: ItineraryDay) => d.dayNumber === sourceDayNumber);
    const destDay = updatedItinerary.days.find((d: ItineraryDay) => d.dayNumber === destDayNumber);
    
    if (!sourceDay || !destDay) {
      console.error('Source or destination day not found');
      return;
    }

    // Get the activity that was moved
    const [movedActivity] = sourceDay.activities.splice(source.index, 1);
    
    // Insert the activity at its new position in the destination day
    destDay.activities.splice(destination.index, 0, movedActivity);
    
    // Update the itinerary
    onUpdateItinerary(updatedItinerary);
  };

  const handleDeleteItinerary = () => {
    if (onDelete) {
      onDelete(itinerary.destination);
      onClose();
    }
  };

  return (
    <Sheet open={true} onOpenChange={(open) => !open && onClose()}>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto" side="right">
        <SheetHeader className="flex justify-between items-center">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" onClick={onClose} className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <SheetTitle>{itinerary.destination} Itinerary</SheetTitle>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => {}}>
              <FileEdit className="h-4 w-4 mr-1" /> Edit
            </Button>
            <Button variant="outline" size="sm" onClick={() => {}}>
              <Share className="h-4 w-4 mr-1" /> Share
            </Button>
            {onDelete && (
              <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" className="text-red-500 border-red-200 hover:bg-red-50">
                    <Trash2 className="h-4 w-4 mr-1" /> Delete
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Itinerary</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to delete this itinerary for {itinerary.destination}?
                      This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDeleteItinerary}>
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        </SheetHeader>
        
        <div className="py-6">
          {/* Itinerary overview */}
          <Card className="p-4 mb-6">
            <h3 className="font-medium text-lg mb-2">Trip Overview</h3>
            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
              <div>
                <p className="text-gray-500">Dates</p>
                <p>{itinerary.startDate} - {itinerary.endDate}</p>
              </div>
              <div>
                <p className="text-gray-500">Duration</p>
                <p>{itinerary.duration} days</p>
              </div>
            </div>
            
            {itinerary.overview && (
              <div className="mb-4">
                <p className="text-gray-500 text-sm">Description</p>
                <p className="text-sm">{itinerary.overview.summary}</p>
              </div>
            )}
            
            {itinerary.overview?.travelTips && itinerary.overview.travelTips.length > 0 && (
              <div>
                <p className="text-gray-500 text-sm mb-1">Travel Tips</p>
                <ul className="text-sm list-disc pl-5">
                  {itinerary.overview.travelTips.slice(0, 3).map((tip: any, index: number) => (
                    <li key={`tip-${index}`}>{tip.tip}</li>
                  ))}
                </ul>
              </div>
            )}
          </Card>
          
          {/* Days with drag and drop */}
          <div className="space-y-4">
            {itinerary.days.map((day) => (
              <DraggableItineraryDay
                key={`day-${day.dayNumber}`}
                day={day}
                dayNumber={day.dayNumber}
                itinerary={itinerary}
                onUpdateItinerary={onUpdateItinerary}
              />
            ))}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default DraggableItineraryDetails;