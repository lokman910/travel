import { useLocation, Link } from "wouter";
import { Globe, MapPin, User, LogIn, Compass } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";

const BottomNavigation = () => {
  const [location, setLocation] = useLocation();
  const { currentUser } = useAuth();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-ventu-white shadow-lg z-10">
      <div className="max-w-lg mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex flex-col items-center p-2 relative">
            {location === "/" && (
              <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-ventu-teal rounded-full" />
            )}
            <Compass 
              className={`h-5 w-5 ${location === "/" 
                ? "text-ventu-teal" 
                : "text-ventu-navy"}`} 
            />
            <span 
              className={`text-xs mt-1 font-medium ${location === "/" 
                ? "text-ventu-teal" 
                : "text-ventu-gray"}`}
            >
              Explore
            </span>
          </Link>

          <Link href="/plan" className="flex flex-col items-center p-2 relative">
            {location === "/plan" && (
              <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-ventu-teal rounded-full" />
            )}
            <MapPin 
              className={`h-5 w-5 ${location === "/plan" 
                ? "text-ventu-teal" 
                : "text-ventu-navy"}`} 
            />
            <span 
              className={`text-xs mt-1 font-medium ${location === "/plan" 
                ? "text-ventu-teal" 
                : "text-ventu-gray"}`}
            >
              Plan
            </span>
          </Link>

          {currentUser ? (
            <Link href="/profile" className="flex flex-col items-center p-2 relative">
              {location === "/profile" && (
                <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-ventu-teal rounded-full" />
              )}
              <User 
                className={`h-5 w-5 ${location === "/profile" 
                  ? "text-ventu-teal" 
                  : "text-ventu-navy"}`} 
              />
              <span 
                className={`text-xs mt-1 font-medium ${location === "/profile" 
                  ? "text-ventu-teal" 
                  : "text-ventu-gray"}`}
              >
                Profile
              </span>
            </Link>
          ) : (
            <Button 
              size="sm" 
              className="rounded-full bg-ventu-coral hover:bg-ventu-coral/90 text-white shadow-md" 
              onClick={() => setLocation("/login")}
            >
              <LogIn className="h-4 w-4 mr-1" />
              Login
            </Button>
          )}
        </div>
      </div>
    </nav>
  );
};

export default BottomNavigation;