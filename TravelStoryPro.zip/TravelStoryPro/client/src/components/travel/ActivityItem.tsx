import { Activity } from "@shared/schema";

interface ActivityItemProps {
  activity: Activity;
  onEdit?: (id: number) => void;
}

const ActivityItem = ({ activity, onEdit }: ActivityItemProps) => {
  const getActivityIcon = () => {
    switch (activity.type) {
      case "flight":
        return { icon: "flight_land", bgColor: "bg-primary/10", textColor: "text-primary" };
      case "hotel":
        return { icon: "hotel", bgColor: "bg-stone", textColor: "text-slate" };
      case "restaurant":
        return { icon: "restaurant", bgColor: "bg-stone", textColor: "text-slate" };
      case "museum":
        return { icon: "museum", bgColor: "bg-stone", textColor: "text-slate" };
      case "tour":
        return { icon: "tour", bgColor: "bg-stone", textColor: "text-slate" };
      default:
        return { icon: "place", bgColor: "bg-stone", textColor: "text-slate" };
    }
  };
  
  const { icon, bgColor, textColor } = getActivityIcon();
  
  return (
    <div className="flex items-start mb-3">
      <div className={`${bgColor} rounded-full p-2 mr-3`}>
        <span className={`material-icons ${textColor} text-sm`}>{icon}</span>
      </div>
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <p className="font-medium text-sm">{activity.title}</p>
          <span className="text-xs text-slate">{activity.time}</span>
        </div>
        <p className="text-xs text-slate mt-0.5">{activity.location}</p>
      </div>
    </div>
  );
};

export default ActivityItem;
