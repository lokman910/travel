import { useState } from "react";
import { Story } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface StoryCardProps {
  story: Story;
  authorName: string;
  authorAvatar: string;
}

const StoryCard = ({ story, authorName, authorAvatar }: StoryCardProps) => {
  const [isBookmarked, setIsBookmarked] = useState(false);
  
  const toggleBookmark = () => {
    setIsBookmarked(!isBookmarked);
  };
  
  return (
    <div className="mb-6 bg-white rounded-xl overflow-hidden shadow-sm">
      <div className="relative h-64">
        <img 
          src={story.coverImage} 
          className="w-full h-full object-cover" 
          alt={story.title} 
        />
        <div className="absolute inset-0 story-card-gradient pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 p-4 text-white">
          <h3 className="font-bold text-lg">{story.title}</h3>
          <div className="flex items-center mt-1">
            <img 
              src={authorAvatar} 
              className="w-6 h-6 rounded-full object-cover mr-2" 
              alt={`${authorName} avatar`} 
            />
            <span className="text-sm">{authorName}</span>
          </div>
        </div>
        <button 
          className="absolute top-4 right-4 bg-white/20 backdrop-blur-md p-1.5 rounded-full"
          onClick={toggleBookmark}
        >
          <span className="material-icons text-white">
            {isBookmarked ? "bookmark" : "bookmark_border"}
          </span>
        </button>
      </div>
      <div className="p-4">
        <div className="flex items-center text-sm text-slate mb-3">
          <span className="material-icons text-xs mr-1">calendar_today</span>
          <span>{formatDistanceToNow(new Date(story.createdAt), { addSuffix: true })}</span>
          <span className="mx-2">•</span>
          <span className="material-icons text-xs mr-1">place</span>
          <span>{story.location}</span>
        </div>
        <p className="text-sm">{story.content}</p>
        <div className="mt-4 flex items-center justify-between">
          <div className="flex gap-3">
            <button className="flex items-center text-slate">
              <span className="material-icons text-sm mr-1">favorite_border</span>
              <span className="text-xs">{story.likes}</span>
            </button>
            <button className="flex items-center text-slate">
              <span className="material-icons text-sm mr-1">chat_bubble_outline</span>
              <span className="text-xs">{story.comments}</span>
            </button>
          </div>
          <button className="text-xs font-medium text-primary">See Itinerary</button>
        </div>
      </div>
    </div>
  );
};

export default StoryCard;
