import { useEffect, useRef, useState } from "react";
import { Place } from "@shared/schema";

interface MapViewProps {
  places?: Place[];
  onPlaceSelect?: (place: Place) => void;
}

const MapView = ({ places = [], onPlaceSelect }: MapViewProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedPlace, setSelectedPlace] = useState<Place | null>(null);
  
  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    // Would filter map markers based on category in a real implementation
  };
  
  const handlePlaceClick = (place: Place) => {
    setSelectedPlace(place);
    if (onPlaceSelect) {
      onPlaceSelect(place);
    }
  };
  
  const getRandomPlace = (): Place => {
    // This would be removed in a real implementation with Google Maps API
    const dummyPlace: Place = {
      id: 1,
      userId: 1,
      tripId: 1,
      name: "Café Le Marais",
      category: "food",
      address: "35 Rue des Archives, 75004 Paris, France",
      lat: "48.8589",
      lng: "2.3469",
      rating: "4.5",
      photo: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa"
    };
    
    return dummyPlace;
  };
  
  useEffect(() => {
    // Would initialize Google Maps API here in a real implementation
    if (places.length === 0) {
      setSelectedPlace(getRandomPlace());
    }
  }, [places]);
  
  return (
    <div className="relative h-[calc(100vh-180px)]">
      {/* Map placeholder - would be replaced with Google Maps API in real implementation */}
      <div 
        ref={mapRef}
        className="w-full h-full bg-stone flex items-center justify-center"
      >
        <img 
          src="https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83" 
          className="w-full h-full object-cover" 
          alt="Map interface" 
        />
        
        {/* Map Controls Overlay */}
        <div className="absolute bottom-4 right-4 flex flex-col gap-2">
          <button className="bg-white rounded-full p-2 shadow-md">
            <span className="material-icons">my_location</span>
          </button>
          <button className="bg-white rounded-full p-2 shadow-md">
            <span className="material-icons">add</span>
          </button>
          <button className="bg-white rounded-full p-2 shadow-md">
            <span className="material-icons">remove</span>
          </button>
        </div>
        
        {/* Map Filters */}
        <div className="absolute top-4 left-0 right-0 px-4">
          <div className="bg-white shadow-md rounded-full p-1 flex overflow-x-auto scrollbar-hide gap-1">
            <button 
              className={`text-xs font-medium py-1.5 px-3 rounded-full whitespace-nowrap ${
                selectedCategory === "all" ? "bg-primary text-white" : "text-slate"
              }`}
              onClick={() => handleCategoryChange("all")}
            >
              All
            </button>
            <button 
              className={`text-xs font-medium py-1.5 px-3 rounded-full whitespace-nowrap ${
                selectedCategory === "food" ? "bg-primary text-white" : "text-slate"
              }`}
              onClick={() => handleCategoryChange("food")}
            >
              Food
            </button>
            <button 
              className={`text-xs font-medium py-1.5 px-3 rounded-full whitespace-nowrap ${
                selectedCategory === "attractions" ? "bg-primary text-white" : "text-slate"
              }`}
              onClick={() => handleCategoryChange("attractions")}
            >
              Attractions
            </button>
            <button 
              className={`text-xs font-medium py-1.5 px-3 rounded-full whitespace-nowrap ${
                selectedCategory === "hotels" ? "bg-primary text-white" : "text-slate"
              }`}
              onClick={() => handleCategoryChange("hotels")}
            >
              Hotels
            </button>
            <button 
              className={`text-xs font-medium py-1.5 px-3 rounded-full whitespace-nowrap ${
                selectedCategory === "shopping" ? "bg-primary text-white" : "text-slate"
              }`}
              onClick={() => handleCategoryChange("shopping")}
            >
              Shopping
            </button>
          </div>
        </div>
        
        {/* Place Card Preview */}
        {selectedPlace && (
          <div className="absolute bottom-16 left-0 right-0 px-4">
            <div className="bg-white rounded-xl shadow-md p-3 flex gap-3">
              <img 
                src={selectedPlace.photo} 
                className="w-20 h-20 rounded-lg object-cover" 
                alt={selectedPlace.name} 
              />
              <div className="flex-1">
                <h3 className="font-bold">{selectedPlace.name}</h3>
                <div className="flex items-center mt-1">
                  {[...Array(Math.floor(parseFloat(selectedPlace.rating)))].map((_, i) => (
                    <span key={i} className="material-icons text-sunset text-xs">star</span>
                  ))}
                  {parseFloat(selectedPlace.rating) % 1 >= 0.5 && (
                    <span className="material-icons text-sunset text-xs">star_half</span>
                  )}
                  <span className="text-xs text-slate ml-1">(247)</span>
                </div>
                <p className="text-xs text-slate mt-1">{selectedPlace.category === "food" ? "French café" : selectedPlace.category} • 0.3 mi away</p>
                <div className="flex gap-2 mt-2">
                  <button className="flex-1 bg-primary/10 text-primary text-xs font-medium py-1.5 rounded">Save</button>
                  <button className="flex-1 bg-primary text-white text-xs font-medium py-1.5 rounded">Directions</button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MapView;
