
import { Card } from "@/components/ui/card";
import { format } from "date-fns";
import { Calendar, MapPin, Users, Clock } from "lucide-react";

export interface ItineraryCardProps {
  title: string;
  destination: string;
  startDate: string;
  endDate: string;
  travelers: number;
  paceLevel: string;
  coverImage: string;
  onView: () => void;
  onEdit: () => void;
  onShare: () => void;
}

export const ItineraryCard = ({
  title,
  destination,
  startDate,
  endDate,
  travelers,
  paceLevel,
  coverImage,
  onView,
  onEdit,
  onShare
}: ItineraryCardProps) => {
  const duration = Math.ceil((new Date(endDate).getTime() - new Date(startDate).getTime()) / (1000 * 3600 * 24));
  
  return (
    <Card className="overflow-hidden group hover:shadow-xl transition-all duration-300">
      <div className="relative h-48">
        <img 
          src={coverImage} 
          alt={destination}
          className="w-full h-full object-cover brightness-90 group-hover:brightness-100 transition-all duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4">
          <h3 className="text-xl font-semibold text-white mb-1">{title}</h3>
          <div className="flex items-center text-white/90 text-sm">
            <MapPin className="w-4 h-4 mr-1" />
            {destination}
          </div>
        </div>
      </div>
      
      <div className="p-4 space-y-4">
        <div className="flex items-center justify-between text-sm text-gray-600">
          <div className="flex items-center">
            <Calendar className="w-4 h-4 mr-1" />
            {format(new Date(startDate), "MMM d")} - {format(new Date(endDate), "MMM d")}
            <span className="ml-1">({duration} days)</span>
          </div>
          <div className="flex items-center">
            <Users className="w-4 h-4 mr-1" />
            {travelers}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-gray-500" />
          <span className="text-sm font-medium capitalize">{paceLevel} pace</span>
        </div>

        <div className="flex gap-2">
          <button onClick={onView} className="flex-1 py-2 px-4 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">
            View
          </button>
          <button onClick={onEdit} className="flex-1 py-2 px-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            Edit
          </button>
          <button onClick={onShare} className="flex-1 py-2 px-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            Share
          </button>
        </div>
      </div>
    </Card>
  );
};
