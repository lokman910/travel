import { Trip } from "@shared/schema";
import { format } from "date-fns";

interface TripCardProps {
  trip: Trip;
  compact?: boolean;
}

const TripCard = ({ trip, compact = false }: TripCardProps) => {
  const startDate = new Date(trip.startDate);
  const endDate = new Date(trip.endDate);
  const duration = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
  
  const formatDate = (date: Date) => format(date, "MMM d");
  
  const getStatusBadge = () => {
    let statusText = "";
    let statusClass = "";
    
    switch (trip.status) {
      case "draft":
        statusText = "Draft";
        break;
      case "in-progress":
        statusText = "In Progress";
        break;
      case "upcoming":
        statusText = "Upcoming";
        break;
      case "completed":
        statusText = "Completed";
        break;
      default:
        statusText = trip.status;
    }
    
    return (
      <div className="absolute top-3 right-3 bg-white/20 backdrop-blur-md py-1 px-2 rounded-full">
        <span className="text-xs text-white font-medium">{statusText}</span>
      </div>
    );
  };
  
  if (compact) {
    return (
      <div className="bg-white rounded-xl overflow-hidden shadow-sm mb-3">
        <div className="relative h-28">
          <img 
            src={trip.coverImage} 
            className="w-full h-full object-cover" 
            alt={trip.title} 
          />
          <div className="absolute inset-0 story-card-gradient pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 p-3 text-white">
            <h3 className="font-bold">{trip.title}</h3>
            <p className="text-xs">
              {formatDate(startDate)}-{formatDate(endDate)} • {duration} days
            </p>
          </div>
          {getStatusBadge()}
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-sm">
      <div className="relative h-40">
        <img 
          src={trip.coverImage} 
          className="w-full h-full object-cover" 
          alt={trip.title} 
        />
        <div className="absolute inset-0 story-card-gradient pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 p-4 text-white">
          <h3 className="font-bold text-lg">{trip.title}</h3>
          <p className="text-sm">
            {formatDate(startDate)}-{formatDate(endDate)}, {new Date(trip.startDate).getFullYear()} • {duration} days
          </p>
        </div>
        {getStatusBadge()}
      </div>
    </div>
  );
};

export default TripCard;
