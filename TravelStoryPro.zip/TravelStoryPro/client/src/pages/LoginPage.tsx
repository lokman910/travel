
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Link } from "wouter";
import { FcGoogle } from "react-icons/fc";
import { SiFacebook } from "react-icons/si";
import { FirebaseError } from 'firebase/app';

const LoginPage = () => {
  // State for auth
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  
  // Auth context and navigation
  const { signInWithGoogle, signInWithFacebook } = useAuth();
  const [, setLocation] = useLocation();

  // Format Firebase error messages for user-friendly display
  const formatFirebaseError = (error: FirebaseError): string => {
    const errorCode = error.code;
    console.log("Firebase error code:", errorCode);
    console.log("Firebase error message:", error.message);
    
    switch (errorCode) {
      case 'auth/user-disabled':
        return 'This account has been disabled.';
      case 'auth/too-many-requests':
        return 'Too many failed login attempts. Please try again later.';
      case 'auth/popup-closed-by-user':
        return 'Sign-in popup was closed before completing the sign in. Please try again.';
      case 'auth/cancelled-popup-request':
        return 'The sign-in process was interrupted. Please try again.';
      case 'auth/popup-blocked':
        return 'The sign-in popup was blocked by your browser. Please allow popups for this site and try again.';
      case 'auth/operation-not-allowed':
        return 'This sign-in method is not enabled in Firebase. The app needs to be configured properly in the Firebase Console.';
      case 'auth/account-exists-with-different-credential':
        return 'An account already exists with the same email address but different sign-in credentials. Try signing in with a different method.';
      case 'auth/unauthorized-domain':
        return 'This domain is not authorized for OAuth operations in Firebase. The app needs to be properly configured in the Firebase Console.';
      case 'auth/configuration-not-found':
        return 'The authentication service is misconfigured. Please contact support.';
      default:
        // If it's a Facebook auth issue
        if (error.message.includes('facebook')) {
          return 'Facebook login failed. The app may not be properly configured in the Facebook Developer Console.';
        }
        // If it's a Google auth issue
        if (error.message.includes('google')) {
          return 'Google login failed. The app may not be properly configured in the Google Cloud Console.';
        }
        return error.message || 'An error occurred during authentication.';
    }
  };



  // Handle social login with Google
  const handleGoogleSignIn = async () => {
    try {
      setIsLoggingIn(true);
      await signInWithGoogle();
      setLocation('/');
    } catch (err) {
      if (err instanceof FirebaseError) {
        setLoginError(formatFirebaseError(err));
      } else {
        setLoginError('Failed to sign in with Google');
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Handle social login with Facebook
  const handleFacebookSignIn = async () => {
    try {
      setIsLoggingIn(true);
      await signInWithFacebook();
      setLocation('/');
    } catch (err) {
      if (err instanceof FirebaseError) {
        setLoginError(formatFirebaseError(err));
      } else {
        setLoginError('Failed to sign in with Facebook');
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Navigation
  const [searchParams] = useLocation();
  
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-sm">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold tracking-tight">Travel Story</h1>
          <p className="text-muted-foreground mt-1">Your journey begins here</p>
        </div>
        
        <Card>
          <CardHeader className="text-center">
            <CardTitle>Sign in</CardTitle>
            <CardDescription>
              Connect with your favorite social account
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-2">
            {loginError && (
              <Alert variant="destructive" className="mb-4">
                <AlertDescription>{loginError}</AlertDescription>
              </Alert>
            )}
            
            <div className="grid gap-3">
              <Button variant="outline" type="button" onClick={handleGoogleSignIn} className="w-full py-5">
                <FcGoogle className="mr-2 h-5 w-5" />
                Continue with Google
              </Button>
              <Button variant="outline" type="button" onClick={handleFacebookSignIn} className="w-full py-5">
                <SiFacebook className="mr-2 h-5 w-5 text-blue-600" />
                Continue with Facebook
              </Button>
            </div>
            
            <div className="mt-6 pt-3 text-center">
              <p className="text-center text-xs text-muted-foreground">
                By signing in, you agree to our <Link href="/terms" className="underline">Terms</Link> and <Link href="/privacy" className="underline">Privacy Policy</Link>
              </p>
            </div>
          </CardContent>
        </Card>
        
        <div className="mt-4 text-center">
          <Link href="/" className="text-primary text-sm hover:underline">
            Skip login and continue as guest
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
