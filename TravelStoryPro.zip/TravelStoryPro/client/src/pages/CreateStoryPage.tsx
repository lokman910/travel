import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Trip } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

const CreateStoryPage = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [content, setContent] = useState("");
  const [selectedTrip, setSelectedTrip] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("classic");
  const [photos, setPhotos] = useState<string[]>([
    "https://images.unsplash.com/photo-1499856871958-5b9627545d1a",
    "https://images.unsplash.com/photo-1502602898657-3e91760cbb34"
  ]);
  
  const { data: trips = [] } = useQuery<Trip[]>({
    queryKey: ["/api/trips", { userId: 1 }]
  });
  
  const createStoryMutation = useMutation({
    mutationFn: async (storyData: any) => {
      const res = await apiRequest("POST", "/api/stories", storyData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stories"] });
      toast({
        title: "Story created",
        description: "Your story has been published successfully.",
      });
      navigate("/");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create story: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleSubmit = () => {
    if (!title || !location || !content) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    createStoryMutation.mutate({
      userId: 1,
      tripId: selectedTrip ? parseInt(selectedTrip) : null,
      title,
      location,
      coverImage: photos[0],
      content,
      photos,
    });
  };
  
  const handleGoBack = () => {
    navigate(-1);
  };
  
  return (
    <div>
      {/* Header */}
      <header className="px-4 py-3 flex items-center justify-between sticky top-0 bg-cloud z-10">
        <button className="p-1" onClick={handleGoBack}>
          <span className="material-icons">arrow_back</span>
        </button>
        <h1 className="text-lg font-bold">Create Story</h1>
        <button 
          className="bg-primary text-white text-sm font-medium py-1.5 px-3 rounded-full"
          onClick={handleSubmit}
          disabled={createStoryMutation.isPending}
        >
          {createStoryMutation.isPending ? "Publishing..." : "Publish"}
        </button>
      </header>
      
      {/* Story Creation Form */}
      <div className="px-4 py-3">
        {/* Title Input */}
        <div className="mb-5">
          <label className="block text-sm font-medium mb-1">Story Title</label>
          <input 
            type="text" 
            className="w-full p-3 border border-stone rounded-lg" 
            placeholder="Add a catchy title..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        
        {/* Location Input */}
        <div className="mb-5">
          <label className="block text-sm font-medium mb-1">Location</label>
          <div className="relative">
            <span className="absolute left-3 top-3 material-icons text-slate">place</span>
            <input 
              type="text" 
              className="w-full p-3 pl-10 border border-stone rounded-lg" 
              placeholder="Add location..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>
        </div>
        
        {/* Travel Dates */}
        <div className="mb-5">
          <label className="block text-sm font-medium mb-1">Travel Dates</label>
          <div className="flex gap-3">
            <div className="relative flex-1">
              <span className="absolute left-3 top-3 material-icons text-slate">calendar_today</span>
              <input 
                type="date" 
                className="w-full p-3 pl-10 border border-stone rounded-lg" 
                placeholder="Start date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div className="relative flex-1">
              <span className="absolute left-3 top-3 material-icons text-slate">calendar_today</span>
              <input 
                type="date" 
                className="w-full p-3 pl-10 border border-stone rounded-lg" 
                placeholder="End date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
        </div>
        
        {/* Photo Upload */}
        <div className="mb-5">
          <label className="block text-sm font-medium mb-1">Photos</label>
          <div className="grid grid-cols-3 gap-2 mb-2">
            {photos.map((photo, index) => (
              <div key={index} className="aspect-square rounded-lg overflow-hidden">
                <img src={photo} className="w-full h-full object-cover" alt={`Travel photo ${index + 1}`} />
              </div>
            ))}
            <div className="aspect-square bg-stone rounded-lg flex items-center justify-center">
              <span className="material-icons text-slate">add_photo_alternate</span>
            </div>
          </div>
          <button className="w-full py-2 border border-dashed border-slate rounded-lg text-sm text-slate flex items-center justify-center">
            <span className="material-icons mr-1 text-sm">add</span>
            Add More Photos
          </button>
        </div>
        
        {/* Story Content */}
        <div className="mb-5">
          <label className="block text-sm font-medium mb-1">Story Content</label>
          <textarea 
            className="w-full p-3 border border-stone rounded-lg h-32" 
            placeholder="Share your travel experience..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
          ></textarea>
        </div>
        
        {/* Trip Association */}
        <div className="mb-5">
          <label className="block text-sm font-medium mb-1">Link to Trip (Optional)</label>
          <select 
            className="w-full p-3 border border-stone rounded-lg bg-white"
            value={selectedTrip}
            onChange={(e) => setSelectedTrip(e.target.value)}
          >
            <option value="">Select a trip</option>
            {trips.map((trip) => (
              <option key={trip.id} value={trip.id}>
                {trip.title} ({new Date(trip.startDate).toLocaleDateString()}-{new Date(trip.endDate).toLocaleDateString()})
              </option>
            ))}
          </select>
        </div>
        
        {/* Template Selection */}
        <div>
          <label className="block text-sm font-medium mb-1">Story Template</label>
          <div className="grid grid-cols-3 gap-2">
            <div 
              className={`${
                selectedTemplate === "classic" ? "border-2 border-primary" : "border border-stone"
              } rounded-lg p-2 aspect-[3/4] flex flex-col items-center`}
              onClick={() => setSelectedTemplate("classic")}
            >
              <div className="w-full h-1/2 bg-primary/20 rounded"></div>
              <div className="w-full h-1/4 mt-1 bg-primary/10 rounded"></div>
              <div className="w-full h-1/8 mt-1 bg-primary/10 rounded"></div>
              <p className={`text-[10px] ${
                selectedTemplate === "classic" ? "text-primary" : "text-slate"
              } font-medium mt-auto`}>Classic</p>
            </div>
            <div 
              className={`${
                selectedTemplate === "photo-grid" ? "border-2 border-primary" : "border border-stone"
              } rounded-lg p-2 aspect-[3/4] flex flex-col items-center`}
              onClick={() => setSelectedTemplate("photo-grid")}
            >
              <div className="w-full h-1/3 bg-stone rounded"></div>
              <div className="w-full h-1/3 mt-1 bg-stone rounded"></div>
              <div className="w-full h-1/8 mt-1 bg-stone rounded"></div>
              <p className={`text-[10px] ${
                selectedTemplate === "photo-grid" ? "text-primary" : "text-slate"
              } font-medium mt-auto`}>Photo Grid</p>
            </div>
            <div 
              className={`${
                selectedTemplate === "cover-story" ? "border-2 border-primary" : "border border-stone"
              } rounded-lg p-2 aspect-[3/4] flex flex-col items-center`}
              onClick={() => setSelectedTemplate("cover-story")}
            >
              <div className="w-full h-2/3 bg-stone rounded"></div>
              <div className="w-full h-1/8 mt-1 bg-stone rounded"></div>
              <p className={`text-[10px] ${
                selectedTemplate === "cover-story" ? "text-primary" : "text-slate"
              } font-medium mt-auto`}>Cover Story</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateStoryPage;
