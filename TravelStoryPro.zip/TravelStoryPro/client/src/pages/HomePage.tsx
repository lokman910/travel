import { useEffect, useState, useRef } from 'react';
import { useQuery } from "@tanstack/react-query";
import { Story, User, Trip, Place } from "@shared/schema";

// Google Maps TypeScript declarations
// Add TypeScript declaration for Google Maps
declare global {
  interface Window {
    google?: {
      maps: {
        Map: new (element: HTMLElement, options: any) => any;
        Marker: new (options: any) => any;
        InfoWindow: new (options: any) => any;
        LatLng: new (lat: number, lng: number) => any;
        SymbolPath: {
          CIRCLE: number;
          FORWARD_CLOSED_ARROW: number;
          FORWARD_OPEN_ARROW: number;
          BACKWARD_CLOSED_ARROW: number;
          BACKWARD_OPEN_ARROW: number;
        };
        Animation: {
          DROP: number;
          BOUNCE: number;
        };
        event: {
          addListener: (instance: any, eventName: string, handler: Function) => void;
          removeListener: (listener: any) => void;
          clearInstanceListeners: (instance: any) => void;
        };
      };
    };
  }
}

// We'll use a proxy endpoint instead of directly using the API key
const googleMapsURL = '/api/maps/js?libraries=places';

// We'll load the Google Maps script dynamically with a typing-friendly interface
const loadGoogleMapsScript = (): Promise<void> => {
  const existingScript = document.getElementById('google-maps-script');
  if (!existingScript) {
    const script = document.createElement('script');
    script.src = googleMapsURL;
    script.id = 'google-maps-script';
    script.async = true;
    script.defer = true;
    document.head.appendChild(script);

    return new Promise<void>((resolve, reject) => {
      script.onload = () => resolve();
      script.onerror = (error) => reject(new Error('Failed to load Google Maps script'));
    });
  }

  return Promise.resolve();
};
import { format, formatISO } from "date-fns";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LogIn, UserPlus, MapPin, Loader2, Calendar, Info, Clock } from "lucide-react";
import * as LocationService from "@/services/LocationService";
import { toast } from "@/hooks/use-toast";

// Quick intents for user selection
const quickIntents = [
  { id: "food", name: "Looking for Food", icon: "restaurant" },
  { id: "relax", name: "Want to Relax", icon: "spa" },
  { id: "adventure", name: "Adventure Time", icon: "hiking" },
  { id: "culture", name: "Cultural Sites", icon: "museum" },
  { id: "photo_spots", name: "Photo Spots", icon: "photo_camera" },
  { id: "hidden_gems", name: "Hidden Gems", icon: "stars" },
  { id: "sunset_spots", name: "Sunset Views", icon: "wb_twilight" },
  { id: "local_life", name: "Local Life", icon: "people" }
];

const HomePage = () => {
  const [activeIntent, setActiveIntent] = useState<string | null>(null);
  const [timeBlock, setTimeBlock] = useState("afternoon");
  const [selectedTab, setSelectedTab] = useState("explore");
  const [isMapExpanded, setIsMapExpanded] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [, setLocation] = useLocation();
  const { currentUser } = useAuth();
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');

  // Location state
  const [userLocation, setUserLocation] = useState<LocationService.LocationCoordinates | null>(null);
  const [currentCityInfo, setCurrentCityInfo] = useState<LocationService.CityInfo | null>(null);
  const [userPreferences, setUserPreferences] = useState<string[]>([]);

  // Request location handler
  const requestLocation = async () => {
    console.log("Starting location request...");

    if (!navigator.geolocation) {
      console.error("Geolocation API not supported");
      toast({
        title: "Geolocation Not Supported",
        description: "Your browser doesn't support geolocation services.",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Location Access Required",
      description: "Please allow location access to see nearby attractions.",
    });

    try {
      const options = {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0
      };

      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, options);
      });

      const userCoords = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      };

      setUserLocation(userCoords);

      try {
        const cityInfo = await LocationService.getCurrentCity(userCoords);
        if (cityInfo) {
          setCurrentCityInfo(cityInfo);
          toast({
            title: "Location Found",
            description: `You're currently in ${cityInfo.name}, ${cityInfo.country}`,
          });
        }
      } catch (error) {
        console.error("Failed to get city info:", error);
        toast({
          title: "Location Detection Failed",
          description: "We couldn't determine your current city.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Geolocation error:", error);
      toast({
        title: "Location Access Denied",
        description: "Please enable location services to get recommendations.",
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    if (!userLocation) {
      requestLocation();
    }
  }, []);

  useEffect(() => {
    if (activeIntent) {
      setUserPreferences([activeIntent]);
    } else {
      setUserPreferences([]);
    }
  }, [activeIntent]);

  // Google Maps loading state
  const [googleMapsLoaded, setGoogleMapsLoaded] = useState(false);

  // Load Google Maps script via our secure proxy
  useEffect(() => {
    const loadMaps = async () => {
      try {
        await loadGoogleMapsScript();
        setGoogleMapsLoaded(true);
        console.log('Google Maps API loaded successfully');
      } catch (error) {
        console.error('Failed to load Google Maps API:', error);
        toast({
          title: "Map Loading Error",
          description: "Failed to load Google Maps. Some features may be limited.",
          variant: "destructive"
        });
      }
    };

    loadMaps();
  }, []);

  // Using device time for contextually relevant recommendations

  // Queries
  const { data: perfectPlaces = [], isLoading: isLoadingPerfect, refetch: refetchPerfect } = useQuery<LocationService.PerfectRecommendation[]>({
    queryKey: ['/api/explore/perfect-for-today', userLocation, currentCityInfo, activeIntent],
    queryFn: () => 
      userLocation && currentCityInfo
        ? LocationService.getPerfectRecommendations(
            userLocation,
            currentCityInfo.name,
            currentCityInfo.country,
            activeIntent
          )
        : Promise.resolve([]),
    enabled: !!userLocation && !!currentCityInfo,
  });

  // We've simplified the app to only use perfect recommendations

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-primary text-white py-3 px-6 sticky top-0 z-50 shadow-md flex justify-between items-center">
        <h2 className="font-bold text-lg">Travel Story</h2>
      </div>

      {/* Header with Search and Location */}
      <header className="relative pb-6">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1494522855154-9297ac14b55f"
            alt={currentCityInfo?.name || "Current Location"}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        <div className="relative px-5 pt-10">
          <div className="flex items-center justify-between">
            <div>
              {currentCityInfo ? (
                <>
                  <h1 className="text-3xl font-bold text-white drop-shadow-lg">
                    Explore {currentCityInfo.name}
                  </h1>
                  <p className="text-white/90 text-sm mt-1 font-medium">
                    {format(new Date(), "MMMM d")} • {currentCityInfo.country}
                  </p>
                </>
              ) : userLocation ? (
                <div className="flex items-center">
                  <h1 className="text-3xl font-bold text-white drop-shadow-lg">
                    Finding location...
                  </h1>
                  <Loader2 className="ml-2 h-5 w-5 animate-spin text-white" />
                </div>
              ) : (
                <>
                  <h1 className="text-3xl font-bold text-white drop-shadow-lg">
                    Explore Places
                  </h1>
                  <Button 
                    variant="ghost" 
                    className="text-white mt-2 pl-0" 
                    onClick={requestLocation}
                  >
                    <MapPin className="h-4 w-4 mr-2" />
                    Share Location
                  </Button>
                </>
              )}
            </div>
          </div>

          <div className="mt-6">
            <Input
              type="search"
              placeholder="Search places..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-white/90 backdrop-blur-sm"
            />
          </div>
        </div>
      </header>

      <Tabs defaultValue="explore" className="px-4 mt-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="explore">Explore</TabsTrigger>
          <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
        </TabsList>

        <TabsContent value="explore">
          <div className="grid grid-cols-3 gap-2">
            {quickIntents.map((intent) => (
              <button
                key={intent.id}
                onClick={() => setActiveIntent(activeIntent === intent.id ? null : intent.id)}
                className={`flex flex-col items-center justify-center py-3 px-2 rounded-lg shadow-sm transition-all ${
                  activeIntent === intent.id 
                    ? "bg-white text-primary shadow-md scale-105" 
                    : "bg-white/90 text-gray-700 hover:bg-white hover:shadow-md"
                }`}
              >
                <span className="material-icons mb-1">{intent.icon}</span>
                <span className="text-xs text-center leading-tight font-medium">{intent.name}</span>
              </button>
            ))}
          </div>

          <div className="mt-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold">Perfect for Today</h2>
              <div className="flex items-center space-x-2 bg-white rounded-md p-1 shadow-sm border">
                <Button 
                  size="sm" 
                  variant={viewMode === 'list' ? "default" : "ghost"}
                  onClick={() => setViewMode('list')}
                  className="text-xs gap-1"
                >
                  <span className="material-icons text-sm">view_list</span>
                  List
                </Button>
                <Button 
                  size="sm" 
                  variant={viewMode === 'map' ? "default" : "ghost"}
                  onClick={() => setViewMode('map')}
                  className="text-xs gap-1"
                >
                  <span className="material-icons text-sm">map</span>
                  Map
                </Button>
              </div>
            </div>

            {isLoadingPerfect ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <Card key={i} className="animate-pulse">
                    <div className="h-40 bg-gray-200" />
                    <div className="p-4">
                      <div className="h-4 bg-gray-200 rounded w-3/4" />
                      <div className="h-4 bg-gray-200 rounded w-1/2 mt-2" />
                    </div>
                  </Card>
                ))}
              </div>
            ) : perfectPlaces.length > 0 ? (
              viewMode === 'list' ? (
                // List View
                <div className="space-y-4">
                  {perfectPlaces.map((place, index) => (
                    <Card key={index} className="overflow-hidden group hover:shadow-lg transition-all duration-300">
                      <div className="relative">
                        <img 
                          src={(() => {
                            const photoUrl = place.photoReference 
                              ? `/api/place/photo?reference=${encodeURIComponent(place.photoReference)}&maxwidth=800`
                              : place.photo || `https://source.unsplash.com/800x600/?${encodeURIComponent(place.name + ' ' + place.category)}`;
                            return photoUrl;
                          })()}
                          alt={place.name}
                          className="w-full h-48 object-cover brightness-[0.95] group-hover:brightness-100 transition-all duration-300"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            // Try category-based image if place name fails
                            target.src = `https://source.unsplash.com/800x600/?${encodeURIComponent(place.category)}`;
                            // Add second error handler for ultimate fallback
                            target.onerror = () => {
                              target.onerror = null; // Prevent infinite loop
                              target.src = "https://placehold.co/800x600/e2e8f0/64748b?text=No+Photo+Available";
                            };
                          }}
                        />
                        <div className="absolute top-4 right-4">
                          <Badge className="bg-white/90 backdrop-blur-sm text-primary hover:bg-white">{place.category}</Badge>
                        </div>
                      </div>
                      <div className="p-5">
                        <h3 className="font-semibold text-xl mb-2 group-hover:text-primary transition-colors">{place.name}</h3>
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{place.description}</p>

                        <div className="bg-primary/5 rounded-xl p-4 mb-4 border border-primary/10">
                          <div className="flex items-center gap-2 mb-2">
                            <div className="bg-primary/10 rounded-full p-1">
                              <Info className="h-4 w-4 text-primary" />
                            </div>
                            <p className="text-sm font-medium text-primary">Perfect Today Because</p>
                          </div>
                          <p className="text-sm text-muted-foreground">{place.whyPerfect}</p>
                        </div>

                        <div className="grid grid-cols-2 gap-3 text-sm">
                          {place.bestTimeToVisit && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Calendar className="h-4 w-4 text-primary" />
                              <span>{place.bestTimeToVisit}</span>
                            </div>
                          )}
                          {place.estimatedTimeNeeded && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Clock className="h-4 w-4 text-primary" />
                              <span>{place.estimatedTimeNeeded}</span>
                            </div>
                          )}
                        </div>

                        <Button variant="outline" className="w-full mt-4 group-hover:bg-primary group-hover:text-white transition-all duration-300">
                          View Details
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                // Map View
                <div className="bg-white rounded-xl shadow-sm overflow-hidden transition-all h-[450px] relative">
                  <div 
                    id="map" 
                    className="w-full h-full"
                  >
                    <img 
                      src={`/api/maps/static?center=${userLocation?.lat},${userLocation?.lng}&zoom=13&size=800x450&maptype=roadmap&markers=${encodeURIComponent(`color:red|${userLocation?.lat},${userLocation?.lng}`)}${perfectPlaces.map(place => 
                        place.coordinates ? `&markers=${encodeURIComponent(`color:blue|${place.coordinates.lat},${place.coordinates.lng}`)}` : ''
                      ).join('')}`}
                      className="w-full h-full object-cover"
                      alt="Map showing recommendations"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83";
                      }}
                    />
                  </div>

                  {/* Map Controls */}
                  <div className="absolute bottom-4 right-4 flex flex-col gap-2">
                    <button className="bg-white rounded-full p-2 shadow-md hover:bg-gray-50">
                      <span className="material-icons">my_location</span>
                    </button>
                    <button className="bg-white rounded-full p-2 shadow-md hover:bg-gray-50">
                      <span className="material-icons">add</span>
                    </button>
                    <button className="bg-white rounded-full p-2 shadow-md hover:bg-gray-50">
                      <span className="material-icons">remove</span>
                    </button>
                  </div>
                </div>
              )
            ) : (
              <Card className="p-8 text-center">
                <Info className="h-8 w-8 mx-auto text-muted-foreground" />
                <p className="mt-2">No perfect places found for today</p>
                {!userLocation && (
                  <Button onClick={requestLocation} className="mt-4">
                    <MapPin className="h-4 w-4 mr-2" />
                    Share Location
                  </Button>
                )}
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="itinerary">
          <div className="space-y-4">
            <div className="flex space-x-2">
              {['morning', 'afternoon', 'evening'].map((block) => (
                <Button
                  key={block}
                  variant={timeBlock === block ? "default" : "outline"}
                  onClick={() => setTimeBlock(block)}
                  className="flex-1 capitalize"
                >
                  {block}
                </Button>
              ))}
            </div>

            <Card className="p-8 text-center">
              <Info className="h-8 w-8 mx-auto text-muted-foreground" />
              <p className="mt-2">Itinerary view has been simplified</p>
              <p className="text-muted-foreground text-sm mt-2">We now focus on providing the most contextually relevant recommendations in the Explore tab.</p>
              <Button onClick={() => setSelectedTab("explore")} variant="outline" className="mt-4">
                Go to Explore
              </Button>
            </Card>
          </div>
        </TabsContent>
      </Tabs>



      {/* Map Legend */}
      <div className="px-4 mt-4 mb-20">
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <h3 className="text-sm font-semibold mb-2">Current Time Recommendations</h3>
          <p className="text-xs text-muted-foreground">
            Recommendations are based on your device's time: {new Date().toLocaleTimeString()}
          </p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;