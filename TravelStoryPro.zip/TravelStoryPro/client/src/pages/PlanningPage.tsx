import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Calendar, Edit2, List, Map, UserPlus, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import ItineraryCard from "@/components/itinerary/ItineraryCard";
import ItineraryDetails from "@/components/itinerary/ItineraryDetails";

const PlanningPage = () => {
  const { toast } = useToast();
  const [showCreateTripForm, setShowCreateTripForm] = useState(true);
  const [destination, setDestination] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [travelers, setTravelers] = useState("1");
  const [adventureLevel, setAdventureLevel] = useState("medium");
  const [budgetRange, setBudgetRange] = useState("mid-range");
  const [paceLevel, setPaceLevel] = useState("moderate");
  const [savedItineraries, setSavedItineraries] = useState(() => {
    const saved = localStorage.getItem('savedItineraries');
    return saved ? JSON.parse(saved) : [];
  });
  
  // States for destination autocomplete
  const [destinationSuggestions, setDestinationSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [destinationPhotoReference, setDestinationPhotoReference] = useState(null);

  const paceLevels = [
    { value: "relaxed", label: "Relaxed", color: "bg-emerald-400" },
    { value: "moderate", label: "Moderate", color: "bg-blue-400" },
    { value: "intense", label: "Intense", color: "bg-purple-400" }
  ];
  const [selectedActivities, setSelectedActivities] = useState([]);
  const [isGeneratingItinerary, setIsGeneratingItinerary] = useState(false);
  const [viewingItinerary, setViewingItinerary] = useState(null);

  const activities = [
    { id: "cultural", label: "Cultural" },
    { id: "culinary", label: "Culinary" },
    { id: "entertainment", label: "Entertainment" },
    { id: "outdoor", label: "Outdoor" },
    { id: "shopping", label: "Shopping" },
    { id: "historical", label: "Historical" },
    { id: "relaxation", label: "Relaxation" },
    { id: "adventure", label: "Adventure" }
  ];

  const adventureLevels = ["low", "medium", "high"];
  const budgetRanges = ["budget", "mid-range", "luxury"];

  const handleActivityToggle = (activityId) => {
    if (selectedActivities.includes(activityId)) {
      setSelectedActivities(selectedActivities.filter(id => id !== activityId));
    } else {
      setSelectedActivities([...selectedActivities, activityId]);
    }
  };

  const generateUniqueId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
  };

  const handleGenerateItinerary = async () => {
    if (!destination) {
      toast({
        title: "Destination Required",
        description: "Please enter a destination for your trip.",
        variant: "destructive",
      });
      return;
    }

    if (!startDate || !endDate) {
      toast({
        title: "Dates Required",
        description: "Please select both start and end dates for your trip.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsGeneratingItinerary(true);
      
      // Call the server to generate an AI itinerary
      const itineraryParams = {
        destination,
        startDate,
        endDate,
        travelers: parseInt(travelers),
        adventureLevel,
        budgetRange,
        paceLevel,
        selectedActivities,
        photoReference: destinationPhotoReference
      };
      
      // Log the request parameters for debugging
      console.log("Sending itinerary generation request:", itineraryParams);
      
      // Send the request to the server API
      const response = await fetch('/api/itinerary/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(itineraryParams),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error("Error generating itinerary:", errorData);
        throw new Error(errorData.message || "Failed to generate itinerary");
      }
      
      // Get the generated itinerary from the API response
      const generatedItinerary = await response.json();
      console.log("Generated itinerary:", generatedItinerary);
      
      // Create a new itinerary object with the generated data
      const newItinerary = {
        id: generateUniqueId(),
        destination,
        startDate,
        endDate,
        travelers: parseInt(travelers),
        adventureLevel,
        budgetRange,
        paceLevel,
        selectedActivities,
        photoReference: destinationPhotoReference,
        createdAt: new Date().toISOString(),
        // Add the AI-generated content
        overview: generatedItinerary.overview,
        days: generatedItinerary.days,
        duration: generatedItinerary.duration
      };

      // Add to saved itineraries
      const updatedItineraries = [...savedItineraries, newItinerary];
      setSavedItineraries(updatedItineraries);
      
      // Save to localStorage
      localStorage.setItem('savedItineraries', JSON.stringify(updatedItineraries));

      toast({
        title: "Itinerary Created",
        description: `Your AI-powered itinerary for ${destination} has been created.`,
      });

      // Reset form and switch to saved itineraries view
      setDestination("");
      setStartDate("");
      setEndDate("");
      setTravelers("1");
      setAdventureLevel("medium");
      setBudgetRange("mid-range");
      setPaceLevel("moderate");
      setSelectedActivities([]);
      setShowCreateTripForm(false);
    } catch (error) {
      console.error("Error in handleGenerateItinerary:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate itinerary. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingItinerary(false);
    }
  };

  // Set initial tab based on saved itineraries
  React.useEffect(() => {
    if (savedItineraries.length > 0) {
      setShowCreateTripForm(false);
    }
  }, []);

  return (
    <React.Fragment>
      <div className="min-h-screen bg-gray-50 pb-20">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex gap-4 mb-8">
            <Button
              variant={showCreateTripForm ? "default" : "outline"}
              onClick={() => setShowCreateTripForm(true)}
              className="flex-1"
            >
              <Map className="w-4 h-4 mr-2" />
              Create New
            </Button>
            <Button
              variant={!showCreateTripForm ? "default" : "outline"}
              onClick={() => setShowCreateTripForm(false)}
              className="flex-1"
            >
              <List className="w-4 h-4 mr-2" />
              Saved Itineraries
            </Button>
          </div>

          {showCreateTripForm ? (
            <div className="grid md:grid-cols-2 gap-8">
              {/* Left Column - Form */}
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h2 className="text-2xl font-bold mb-6">Create Your Itinerary</h2>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Destination</label>
                    <div className="relative">
                      <Input
                        placeholder="Where are you going?"
                        value={destination}
                        onChange={(e) => {
                          setDestination(e.target.value);
                          // Only search if we have 3 or more characters
                          if (e.target.value.length >= 3) {
                            fetch(`/api/place/search?query=${encodeURIComponent(e.target.value)}`)
                              .then(res => res.json())
                              .then(data => {
                                setDestinationSuggestions(data);
                                setShowSuggestions(true);
                              })
                              .catch(err => console.error("Error fetching place suggestions:", err));
                          } else {
                            setDestinationSuggestions([]);
                            setShowSuggestions(false);
                          }
                        }}
                        className="w-full"
                      />
                      {showSuggestions && destinationSuggestions.length > 0 && (
                        <div className="absolute z-10 mt-1 w-full bg-white shadow-lg rounded-md max-h-80 overflow-auto border">
                          {destinationSuggestions.map((place) => (
                            <div
                              key={place.placeId}
                              className="p-2 hover:bg-gray-100 cursor-pointer flex items-start border-b"
                              onClick={() => {
                                setDestination(place.name);
                                setDestinationPhotoReference(place.photoReference);
                                setShowSuggestions(false);
                              }}
                            >
                              <div>
                                <div className="font-medium">{place.name}</div>
                                <div className="text-xs text-gray-500">{place.address}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Enter a city, country, or region</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Travel Dates</label>
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        type="date"
                        value={startDate}
                        min={new Date().toISOString().split('T')[0]}
                        onChange={(e) => {
                          setStartDate(e.target.value);
                          // Reset end date if it's before new start date
                          if (endDate && e.target.value > endDate) {
                            setEndDate('');
                          }
                        }}
                      />
                      <Input
                        type="date"
                        value={endDate}
                        min={startDate || new Date().toISOString().split('T')[0]}
                        disabled={!startDate}
                        onChange={(e) => {
                          if (e.target.value >= startDate) {
                            setEndDate(e.target.value);
                          } else {
                            toast({
                              title: "Invalid Date Range",
                              description: "End date must be after start date",
                              variant: "destructive",
                            });
                          }
                        }}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Number of Travelers</label>
                    <Input
                      type="number"
                      min="1"
                      value={travelers}
                      onChange={(e) => setTravelers(e.target.value)}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Adventure Level</label>
                    <div className="flex gap-2">
                      {adventureLevels.map(level => (
                        <Button
                          key={level}
                          variant={adventureLevel === level ? "default" : "outline"}
                          onClick={() => setAdventureLevel(level)}
                          className="flex-1 capitalize"
                        >
                          {level}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Budget Range</label>
                    <div className="flex gap-2">
                      {budgetRanges.map(range => (
                        <Button
                          key={range}
                          variant={budgetRange === range ? "default" : "outline"}
                          onClick={() => setBudgetRange(range)}
                          className="flex-1 capitalize"
                        >
                          {range}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-800">Pace of Travel</h3>
                    <div className="flex gap-3">
                      {paceLevels.map((pace) => (
                        <button
                          key={pace.value}
                          onClick={() => setPaceLevel(pace.value)}
                          className={`flex-1 p-4 rounded-xl transition-all duration-300 ${
                            paceLevel === pace.value
                              ? `${pace.color} text-white scale-105 shadow-lg`
                              : 'bg-gray-100 hover:bg-gray-200'
                          }`}
                        >
                          <div className="font-medium">{pace.label}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-3">Activity Types</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {activities.map(activity => (
                        <Button
                          key={activity.id}
                          variant={selectedActivities.includes(activity.id) ? "default" : "outline"}
                          onClick={() => handleActivityToggle(activity.id)}
                          className="justify-start"
                        >
                          {activity.label}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <Button
                    className="w-full"
                    onClick={handleGenerateItinerary}
                    disabled={isGeneratingItinerary}
                  >
                    {isGeneratingItinerary ? (
                      <React.Fragment>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Generating Itinerary...
                      </React.Fragment>
                    ) : (
                      "Generate Itinerary"
                    )}
                  </Button>
                </div>
              </div>

              {/* Right Column - Info Cards */}
              <div className="space-y-6">
                <Card className="p-6 text-center">
                  <Map className="w-12 h-12 mx-auto mb-4 text-primary" />
                  <h3 className="text-xl font-semibold mb-2">Create Your Perfect Itinerary</h3>
                  <p className="text-gray-600">
                    Fill out the form to generate a personalized travel itinerary based on your preferences.
                    Our AI will create a day-by-day plan for your trip.
                  </p>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="p-4">
                    <Calendar className="w-8 h-8 mb-2 text-green-500" />
                    <h4 className="font-semibold">Day-by-Day Breakdown</h4>
                    <p className="text-sm text-gray-600">View detailed daily activities with times and locations.</p>
                  </Card>

                  <Card className="p-4">
                    <Edit2 className="w-8 h-8 mb-2 text-purple-500" />
                    <h4 className="font-semibold">Save & Edit</h4>
                    <p className="text-sm text-gray-600">Save your itineraries and make edits anytime.</p>
                  </Card>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Your Saved Itineraries</h2>
                <Button onClick={() => setShowCreateTripForm(true)} className="bg-primary hover:bg-primary/90">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Create New
                </Button>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {savedItineraries.length > 0 ? (
                  savedItineraries.map((itinerary) => (
                    <ItineraryCard
                      key={itinerary.id}
                      {...itinerary}
                      onView={() => {
                        setViewingItinerary(itinerary);
                      }}
                      onEdit={() => {
                        toast({
                          title: "Edit Itinerary",
                          description: `Editing itinerary for ${itinerary.destination}`,
                        });
                        // In a full implementation, this would load the itinerary into the form
                      }}
                      onShare={() => {
                        toast({
                          title: "Share Itinerary",
                          description: `Generated share link for ${itinerary.destination}`,
                        });
                        // In a full implementation, this would show a share dialog
                      }}
                    />
                  ))
                ) : (
                  <div className="col-span-full text-center py-10">
                    <div className="text-gray-400 mb-3">No saved itineraries yet</div>
                    <Button onClick={() => setShowCreateTripForm(true)}>
                      Create Your First Itinerary
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
      
      {viewingItinerary && (
        <ItineraryDetails 
          itinerary={viewingItinerary} 
          onClose={() => setViewingItinerary(null)}
          onDelete={(id) => {
            toast({
              title: "Itinerary Deleted",
              description: `Deleted itinerary for ${viewingItinerary.destination}`,
            });
            // In a full implementation, this would call an API to delete the itinerary
            setSavedItineraries(prev => prev.filter(it => it.id !== id));
          }}
        />
      )}
    </React.Fragment>
  );
};

export default PlanningPage;