import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import MapView from "@/components/map/MapView";
import { Place } from "@shared/schema";

const MapPage = () => {
  const [selectedPlace, setSelectedPlace] = useState<Place | null>(null);
  
  const { data: places = [] } = useQuery<Place[]>({
    queryKey: ["/api/places", { userId: 1 }]
  });
  
  const handlePlaceSelect = (place: Place) => {
    setSelectedPlace(place);
  };
  
  return (
    <div>
      {/* Map Header */}
      <header className="px-4 py-3 flex items-center justify-between sticky top-0 bg-cloud z-10">
        <div>
          <h1 className="text-lg font-bold">Explore</h1>
          <p className="text-xs text-slate">Discover places around you</p>
        </div>
        <div className="flex gap-2">
          <button className="p-2 rounded-full hover:bg-stone transition-colors">
            <span className="material-icons text-slate">tune</span>
          </button>
          <button className="p-2 rounded-full hover:bg-stone transition-colors">
            <span className="material-icons text-slate">search</span>
          </button>
        </div>
      </header>
      
      {/* Map View */}
      <MapView 
        places={places} 
        onPlaceSelect={handlePlaceSelect} 
      />
    </div>
  );
};

export default MapPage;
