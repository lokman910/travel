import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Story, Trip, Collection } from "@shared/schema";
import { User as DBUser } from "@shared/schema";
import { useAuth } from "@/contexts/AuthContext";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

const ProfilePage = () => {
  const [activeTab, setActiveTab] = useState("trips");
  const { currentUser, logout } = useAuth();
  const [, setLocation] = useLocation();
  
  // If user is not logged in, redirect to login page
  if (!currentUser) {
    setLocation('/login');
    return null;
  }
  
  // Use the Firebase user's ID to query the database
  const userId = currentUser?.uid || '1'; // Fallback to "1" for development
  
  const { data: user } = useQuery<DBUser>({
    queryKey: ["/api/user/1"] // Will be replaced with userId in production
  });
  
  const { data: stories = [], isLoading: isLoadingStories } = useQuery<Story[]>({
    queryKey: ["/api/stories", { userId: 1 }] // Will be replaced with userId in production
  });
  
  const { data: trips = [], isLoading: isLoadingTrips } = useQuery<Trip[]>({
    queryKey: ["/api/trips", { userId: 1 }] // Will be replaced with userId in production
  });
  
  const handleLogout = async () => {
    try {
      await logout();
      // Redirect will happen in the AuthContext
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };
  
  return (
    <div>
      {/* Profile Header */}
      <div className="pt-6 pb-3 px-4 bg-gradient-to-b from-white to-primary/5">
        <div className="flex items-center">
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1494790108377-be9c29b29330" 
              className="w-20 h-20 rounded-full object-cover shadow-md" 
              alt="User profile"
            />
            <div className="absolute -bottom-1 -right-1 bg-white p-1 rounded-full shadow-sm">
              <span className="material-icons text-primary text-sm">verified</span>
            </div>
          </div>
          <div className="ml-4">
            <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              {user?.displayName || "Emma Wilson"}
            </h1>
            <p className="text-sm text-slate">Travel enthusiast • {user?.countriesVisited || 28} countries</p>
            <button className="mt-2 bg-white shadow-sm border border-primary/20 text-primary text-xs font-medium py-1 px-3 rounded-full hover:bg-primary/5 transition-colors">
              Edit Profile
            </button>
          </div>
          <div className="ml-auto">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLogout} 
              className="text-muted-foreground hover:text-primary"
            >
              <LogOut className="h-4 w-4 mr-1" />
              Logout
            </Button>
          </div>
        </div>
        
        {/* Profile Stats */}
        <div className="flex justify-between mt-6">
          <div className="text-center">
            <p className="font-bold">{trips.length}</p>
            <p className="text-xs text-slate">Trips</p>
          </div>
          <div className="text-center">
            <p className="font-bold">{stories.length}</p>
            <p className="text-xs text-slate">Stories</p>
          </div>
          <div className="text-center">
            <p className="font-bold">142</p>
            <p className="text-xs text-slate">Following</p>
          </div>
          <div className="text-center">
            <p className="font-bold">287</p>
            <p className="text-xs text-slate">Followers</p>
          </div>
        </div>
      </div>
      
      {/* Profile Tabs */}
      <div className="border-b border-stone">
        <div className="flex overflow-x-auto scrollbar-hide">
          <button 
            className={`py-3 px-4 text-sm font-medium whitespace-nowrap ${
              activeTab === "trips" ? "active-tab" : "text-slate"
            }`}
            onClick={() => setActiveTab("trips")}
          >
            Trips
          </button>
          <button 
            className={`py-3 px-4 text-sm font-medium whitespace-nowrap ${
              activeTab === "map" ? "active-tab" : "text-slate"
            }`}
            onClick={() => setActiveTab("map")}
          >
            Map
          </button>
        </div>
      </div>
      
      {/* Trips Grid */}
      {activeTab === "trips" && (
        <div className="p-4">
          {isLoadingTrips ? (
            <div className="flex justify-center py-8">
              <span className="material-icons animate-spin">sync</span>
            </div>
          ) : (
            <div className="space-y-3">
              {trips.map((trip) => (
                <div key={trip.id} className="relative rounded-xl overflow-hidden h-28">
                  <img 
                    src={trip.coverImage} 
                    className="w-full h-full object-cover" 
                    alt={trip.title}
                  />
                  <div className="absolute inset-0 story-card-gradient pointer-events-none"></div>
                  <div className="absolute bottom-2 left-2 text-white">
                    <p className="font-medium">{trip.title}</p>
                    <p className="text-xs">
                      {new Date(trip.startDate).toLocaleDateString("en-US", { month: "short", day: "numeric" })}-
                      {new Date(trip.endDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                    </p>
                  </div>
                  <div className="absolute top-2 right-2 bg-white/20 backdrop-blur-md py-0.5 px-2 rounded-full">
                    <span className="text-[10px] text-white">{trip.status}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
      
      {/* Map Placeholder */}
      {activeTab === "map" && (
        <div className="p-4 flex justify-center items-center h-40 text-slate">
          <div className="text-center">
            <span className="material-icons text-4xl mb-2">public</span>
            <p>Your travel map will appear here</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfilePage;
