import { apiRequest } from '@/lib/queryClient';
import { Place } from '@shared/schema';

// Types from server services
export interface LocationCoordinates {
  lat: number;
  lng: number;
}

export interface CityInfo {
  name: string;
  country: string;
  coordinates: LocationCoordinates;
  description: string;
  photoUrl?: string;
}

export interface PerfectRecommendation {
  name: string;
  description: string;
  category: string;
  whyPerfect: string;
  bestTimeToVisit?: string;
  estimatedTimeNeeded?: string;
  placeId?: string;
  photoReference?: string;
  photo?: string;
  rating?: number;
  totalRatings?: number;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

// Get the user's current city based on coordinates
export async function getCurrentCity(coordinates: LocationCoordinates): Promise<CityInfo> {
  console.log("Client: Getting current city for coordinates:", coordinates);
  try {
    const response = await apiRequest<CityInfo>('/api/location/current', {
      method: 'POST',
      body: JSON.stringify(coordinates),
    });
    
    console.log("Client: Received city info response:", response);
    return response;
  } catch (error) {
    console.error("Client: Error getting current city:", error);
    
    // Provide a fallback on the client side if the API call fails
    const fallbackInfo: CityInfo = {
      name: "Current Location",
      country: "Unknown",
      coordinates: coordinates,
      description: "Your current location. Location services could not determine your city."
    };
    
    console.log("Client: Using fallback city info:", fallbackInfo);
    return fallbackInfo;
  }
}

// Get nearby attractions
export async function getNearbyAttractions(
  coordinates: LocationCoordinates,
  radius?: number,
  type?: string
): Promise<Place[]> {
  return apiRequest<Place[]>('/api/explore/nearby', {
    method: 'POST',
    body: JSON.stringify({
      ...coordinates,
      radius,
      type,
    }),
  });
}

// Get popular destinations near the user
export async function getPopularDestinations(
  coordinates: LocationCoordinates,
  radius?: number
): Promise<CityInfo[]> {
  return apiRequest<CityInfo[]>('/api/explore/destinations', {
    method: 'POST',
    body: JSON.stringify({
      ...coordinates,
      radius,
    }),
  });
}

// Get personalized recommendations for right now
export async function getRecommendationsForNow(
  coordinates: LocationCoordinates,
  city: string,
  country: string,
  intent: string | null = null
): Promise<PerfectRecommendation[]> {
  return apiRequest<PerfectRecommendation[]>('/api/explore/recommendations', {
    method: 'POST',
    body: JSON.stringify({
      ...coordinates,
      city,
      country,
      intent,
      date: new Date().toISOString(),
    }),
  });
}

// Get perfect recommendations for today
export async function getPerfectRecommendations(
  coordinates: LocationCoordinates,
  city: string,
  country: string,
  intent: string | null = null
): Promise<PerfectRecommendation[]> {
  // Always use the device's current time for real-time relevance
  const currentDate = new Date();
  
  console.log(`Getting recommendations for current time: ${currentDate.toLocaleTimeString()}`);
  
  return apiRequest<PerfectRecommendation[]>('/api/explore/perfect-for-today', {
    method: 'POST',
    body: JSON.stringify({
      ...coordinates,
      city,
      country,
      intent,
      date: currentDate.toISOString(),
    }),
  });
}

// Get travel tips for a location
export async function getTravelTips(
  coordinates: LocationCoordinates,
  city: string,
  country: string
): Promise<string[]> {
  return apiRequest<string[]>('/api/explore/travel-tips', {
    method: 'POST',
    body: JSON.stringify({
      ...coordinates,
      city,
      country,
    }),
  });
}

// Interface for detailed place information
export interface PlaceDetails {
  placeId: string;
  name: string;
  formattedAddress: string;
  location: LocationCoordinates;
  photos: any[];
  photoReferences: string[];
  rating: number;
  userRatingsTotal: number;
  types: string[];
  openNow?: boolean;
}

// Get detailed information about a specific place
export async function getPlaceDetails(placeId: string): Promise<PlaceDetails | null> {
  try {
    console.log(`Client: Fetching place details for ${placeId}`);
    const response = await apiRequest<PlaceDetails>(`/api/place/details?placeId=${placeId}`);
    console.log(`Client: Received place details`, response);
    return response;
  } catch (error) {
    console.error("Failed to get place details:", error);
    return null;
  }
}

// Types for itinerary editing
export interface ItineraryActivity {
  time: string;
  name: string;
  description: string;
  location?: string;
  price?: string;
  category?: string;
  isFree?: boolean;
  placeId?: string;
  formattedAddress?: string;
  coordinates?: LocationCoordinates;
  photoReference?: string;
  photoReferences?: string[];
  rating?: number;
  userRatingsTotal?: number;
  types?: string[];
  openNow?: boolean;
}

export interface ItineraryDay {
  date: string;
  dayNumber: number;
  activities: ItineraryActivity[];
}

export interface Itinerary {
  destination: string;
  startDate: string;
  endDate: string;
  duration: number;
  overview: any;
  days: ItineraryDay[];
  photoReference?: string | null;
}

/**
 * Add an activity to an itinerary
 * @param itinerary The itinerary to modify
 * @param dayNumber The day number to add the activity to
 * @param activity The activity to add
 * @returns The updated itinerary
 */
export async function addActivityToItinerary(
  itinerary: Itinerary,
  dayNumber: number,
  activity: ItineraryActivity
): Promise<Itinerary> {
  try {
    const response = await apiRequest<Itinerary>('/api/itinerary/edit', {
      method: 'POST',
      body: JSON.stringify({
        operation: 'add',
        itinerary,
        dayNumber,
        activity
      }),
    });
    return response;
  } catch (error) {
    console.error('Error adding activity to itinerary:', error);
    throw error;
  }
}

/**
 * Remove an activity from an itinerary
 * @param itinerary The itinerary to modify
 * @param dayNumber The day number containing the activity
 * @param activityIndex The index of the activity to remove
 * @returns The updated itinerary
 */
export async function removeActivityFromItinerary(
  itinerary: Itinerary,
  dayNumber: number,
  activityIndex: number
): Promise<Itinerary> {
  try {
    const response = await apiRequest<Itinerary>('/api/itinerary/edit', {
      method: 'POST',
      body: JSON.stringify({
        operation: 'remove',
        itinerary,
        dayNumber,
        activityIndex
      }),
    });
    return response;
  } catch (error) {
    console.error('Error removing activity from itinerary:', error);
    throw error;
  }
}

/**
 * Replace an activity in an itinerary
 * @param itinerary The itinerary to modify
 * @param dayNumber The day number containing the activity
 * @param activityIndex The index of the activity to replace
 * @param activity The new activity
 * @returns The updated itinerary
 */
export async function replaceActivityInItinerary(
  itinerary: Itinerary,
  dayNumber: number,
  activityIndex: number,
  activity: ItineraryActivity
): Promise<Itinerary> {
  try {
    const response = await apiRequest<Itinerary>('/api/itinerary/edit', {
      method: 'POST',
      body: JSON.stringify({
        operation: 'replace',
        itinerary,
        dayNumber,
        activityIndex,
        activity
      }),
    });
    return response;
  } catch (error) {
    console.error('Error replacing activity in itinerary:', error);
    throw error;
  }
}